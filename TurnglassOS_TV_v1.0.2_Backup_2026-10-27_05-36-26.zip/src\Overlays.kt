package io.github.abhishekkaisar.glassos

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsView(private val act: HomeScreen) : FrameLayout(act.ctx) {
    var isOpen = false
        private set
    private val scrim = View(context).apply { setBackgroundColor(0x73000000) }
    private val panelW = dpi(410f)
    private val margin = dpi(26f)
    val panel = GlassBox(context, dp(36f)).apply {
        glass.tint = 0.10f
        glass.dark = 0.30f
        glass.sheen = 0.10f
        shadowAlpha = 0.5f
    }
    private val list = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        clipChildren = false
        clipToPadding = false
    }
    private val nameRow = RowView(context, "Name")
    private val photoRow = RowView(context, "Profile photo")
    private val countryRow = RowView(context, "Country")
    private val shelfRow = RowView(context, "Top Shelf")
    private val keyRow = RowView(context, "TMDB API key")
    private val appsRow = RowView(context, "Top row apps")
    private val hiddenRow = RowView(context, "Hidden apps")
    private val permsRow = RowView(context, "Permissions")
    private val setupRow = RowView(context, "Run setup again")
    private val aboutRow = RowView(context, "About")
    private val uninstallRow = RowView(context, "Prepare to uninstall")
    private val atmoRow = RowView(context, "Atmosphere Sync")
    private val soundRow = RowView(context, "Focus sounds")
    private val bgRow = RowView(context, "Background").apply { isFocusable = false; isClickable = false }
    private val psColorRow = RowView(context, "Nostalgia color")
    private val liquidColorRow = RowView(context, "Liquid Glass style")
    private val editRow = RowView(context, "Edit top row")
    private val allRow = RowView(context, "Show all apps")
    private val replaceRow = RowView(context, "Replace ${Platform.name(context)} home")
    private val fireSettingsRow = RowView(context, "${Platform.name(context)} settings")
    private val fireHomeRow = RowView(context, "${Platform.name(context)} home")
    private val homeAppRow = RowView(context, "Home screen")
    private val scroll = ScrollView(context).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isSmoothScrollingEnabled = true
        clipChildren = false
        clipToPadding = false
    }
    private val thumbsRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false; clipToPadding = false }
    private val thumbsScroll = HorizontalScrollView(context).apply {
        isHorizontalScrollBarEnabled = false
        isHorizontalFadingEdgeEnabled = false
        setFadingEdgeLength(0)
        clipChildren = false
        clipToPadding = false
        isFillViewport = false
        overScrollMode = View.OVER_SCROLL_NEVER
    }
    private val thumbs = ArrayList<ThumbView>()

    init {
        visibility = View.GONE
        clipChildren = false
        addView(scrim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(panel, LayoutParams(panelW, LayoutParams.MATCH_PARENT, Gravity.END).apply { setMargins(margin, margin, margin, margin) })
        val pad = dpi(22f)
        list.setPadding(pad, dpi(8f), pad, dpi(8f))
        scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.clipChildren = false
        panel.addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT).apply {
            topMargin = dpi(12f); bottomMargin = dpi(14f)
        })
        if (android.os.Build.VERSION.SDK_INT >= 23) scroll.setOnScrollChangeListener { _, _, _, _, _ -> invalidateDeep(list) }

        val title = TextView(context).apply {
            text = "Settings"
            textSize = 26f
            typeface = Fonts.medium
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dpi(6f), 0, 0, dpi(8f))
        }
        list.addView(title)
        val rowLp = { LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(48f)).apply { bottomMargin = dpi(5f) } }
        list.addView(nameRow, rowLp())
        list.addView(photoRow, rowLp())
        list.addView(countryRow, rowLp())
        list.addView(shelfRow, rowLp())
        list.addView(keyRow, rowLp())
        list.addView(atmoRow, rowLp())
        list.addView(soundRow, rowLp())
        list.addView(bgRow, rowLp())
        val bgLabel = TextView(context).apply {
            text = "When Top Shelf art is unavailable"
            textSize = 15f
            typeface = Fonts.medium
            setTextColor(0x99FFFFFF.toInt())
            setPadding(dpi(20f), dpi(8f), 0, dpi(2f))
        }
        list.addView(bgLabel)
        thumbsScroll.setPadding(0, dpi(12f), 0, dpi(32f))
        thumbsRow.setPadding(dpi(18f), 0, dpi(18f), 0)
        thumbsScroll.addView(thumbsRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        list.addView(thumbsScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = -dpi(14f); rightMargin = -dpi(14f); bottomMargin = dpi(8f)
        })
        list.addView(psColorRow, rowLp())
        list.addView(liquidColorRow, rowLp())
        list.addView(editRow, rowLp())
        list.addView(appsRow, rowLp())
        list.addView(hiddenRow, rowLp())
        list.addView(allRow, rowLp())
        list.addView(replaceRow, rowLp())
        list.addView(permsRow, rowLp())
        if (!Platform.isFireTv(context)) list.addView(homeAppRow, rowLp())
        list.addView(fireSettingsRow, rowLp())
        if (Platform.stockHome(context) != null) list.addView(fireHomeRow, rowLp())
        list.addView(setupRow, rowLp())
        list.addView(uninstallRow, rowLp())
        list.addView(aboutRow, rowLp())

        fun step(row: View, s: SetupView.Step) { resumeRow = row; act.openSetup(s, single = true) }
        nameRow.onClick = { step(nameRow, SetupView.Step.NAME) }
        photoRow.onClick = { step(photoRow, SetupView.Step.PHOTO) }
        countryRow.onClick = { step(countryRow, SetupView.Step.COUNTRY) }
        keyRow.onClick = { step(keyRow, SetupView.Step.TMDB_KEY) }
        appsRow.onClick = { step(appsRow, SetupView.Step.APPS) }
        hiddenRow.onClick = { step(hiddenRow, SetupView.Step.HIDDEN) }
        permsRow.onClick = { step(permsRow, SetupView.Step.PERMISSIONS) }
        homeAppRow.onClick = { step(homeAppRow, SetupView.Step.HOME) }
        setupRow.onClick = { resumeRow = setupRow; act.openSetup() }
        aboutRow.onClick = { step(aboutRow, SetupView.Step.ABOUT) }
        uninstallRow.onClick = {
            Power.removeAdmin(context)
            act.setReplaceHome(false)
            updateValues()
            postDelayed({ if (isOpen) updateValues() }, 800)
            val msg = if (Platform.isFireTv(context) || !Platform.isDefaultHome(context)) "Device admin removed and ${Platform.name(context)} home restored. You can uninstall GlassOS now."
                else "Device admin removed. Choose your old home in Settings > Apps > Default apps (or on Home), then uninstall GlassOS."
            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
        }
        shelfRow.onClick = {
            val ids = HeroRepo.SOURCES.map { it.first }
            act.setTopShelf(ids[(ids.indexOf(act.prefs.topShelf) + 1) % ids.size])
            updateValues()
        }
        atmoRow.onClick = {
            act.prefs.atmosphereSync = !act.prefs.atmosphereSync
            act.onClockChanged()
            updateValues()
        }
        soundRow.onClick = {
            act.prefs.sound = !act.prefs.sound
            updateValues()
        }
        psColorRow.onClick = {
            act.cyclePsColor()
            updateValues()
        }
        liquidColorRow.onClick = {
            act.cycleLiquidStyle()
            updateValues()
        }
        editRow.onClick = { close { act.enterEdit() } }
        allRow.onClick = { close { act.focusAllApps() } }
        replaceRow.onClick = {
            act.setReplaceHome(!act.prefs.replaceHome)
            updateValues()
        }
        fireSettingsRow.onClick = { close { act.openFireSettings() } }
        fireHomeRow.onClick = { close { act.openAmazonHome() } }
        for (r in listOf(fireSettingsRow, fireHomeRow, photoRow, appsRow, setupRow, aboutRow)) { r.valueView.text = "›"; r.valueView.textSize = 24f }
        allRow.valueView.text = "›"
        editRow.valueView.text = "›"
        allRow.valueView.textSize = 24f
        editRow.valueView.textSize = 24f
    }

    private fun updateValues() {
        val psColors = arrayOf("PlayStation Blue", "Xbox Green", "Amethyst Purple", "Ruby Red", "Monochrome")
        val liqStyles = arrayOf("Prism Iridescent", "Deep Smoked", "Cyber Amber")
        atmoRow.valueView.text = if (act.prefs.atmosphereSync) "On" else "Off"
        soundRow.valueView.text = if (act.prefs.sound) "On" else "Off"
        psColorRow.valueView.text = psColors.getOrElse(act.prefs.psColorIndex) { psColors[0] }
        liquidColorRow.valueView.text = liqStyles.getOrElse(act.prefs.liquidStyle) { liqStyles[0] }
        psColorRow.visibility = if (act.prefs.scene == "scene:nostalgia") View.VISIBLE else View.GONE
        liquidColorRow.visibility = if (act.prefs.scene == "scene:liquid") View.VISIBLE else View.GONE
        val hiddenCount = act.prefs.hidden.count { p -> HomeShare.apps?.any { it.pkg == p } ?: true }
        hiddenRow.valueView.text = if (hiddenCount == 0) "None" else "$hiddenCount"
        nameRow.valueView.text = act.prefs.name.ifEmpty { "Not set" }
        countryRow.valueView.text = act.prefs.country.ifEmpty { "Not set" }.let { c -> if (c.length == 2) java.util.Locale("", c).displayCountry else c }
        shelfRow.valueView.text = HeroRepo.sourceLabel(act.prefs.topShelf)
        keyRow.valueView.text = when {
            act.prefs.tmdbKey.isNotEmpty() -> "Your key"
            BuildConfig.TMDB_API_KEY.isNotEmpty() -> "Built in"
            else -> "Not set"
        }
        permsRow.valueView.text = "${Grants.ALL.count { it.isGranted(context) }} of ${Grants.ALL.size}"
        bgRow.valueView.text = WallpaperStore.label(act.prefs.scene)
        replaceRow.valueView.text = if (act.prefs.replaceHome) "On" else "Off"
        homeAppRow.valueView.text = if (Platform.isDefaultHome(context)) "GlassOS" else "Not GlassOS"
    }

    fun refreshThumbs() {
        thumbsRow.removeAllViews()
        thumbs.clear()
        val ids = WallpaperStore.scenes.map { it.first } + listOf(HeroRepo.PHOTOS) + act.userImageIds()
        val tw = dpi(136f)
        val th = dpi(76f)
        val current = act.prefs.scene
        for ((i, id) in ids.withIndex()) {
            val t = ThumbView(context, tw, th, id, WallpaperStore.label(id))
            t.id = View.generateViewId()
            t.chosen = id == current
            t.onClick = {
                act.setWallpaper(id)
                thumbs.forEach { it.chosen = it.wallId == id }
                updateValues()
            }
            thumbsRow.addView(t, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dpi(16f)
            })
            thumbs.add(t)
        }
        act.loadThumbs(thumbs)
        val chosen = thumbs.firstOrNull { it.chosen } ?: thumbs.firstOrNull()
        soundRow.nextFocusDownId = chosen?.id ?: View.NO_ID
        editRow.nextFocusUpId = chosen?.id ?: View.NO_ID
        if (chosen != null) thumbsScroll.post { thumbsScroll.scrollTo((chosen.left - dpi(18f)).coerceAtLeast(0), 0) }
    }

    private var resumeRow: View? = null

    private fun focusStart() {
        val r = resumeRow
        resumeRow = null
        if (r != null) { r.requestFocus(); return }
        scroll.scrollTo(0, 0)
        nameRow.requestFocus()
    }

    fun open(instant: Boolean = false) {
        if (isOpen) return
        isOpen = true
        updateValues()
        refreshThumbs()
        visibility = View.VISIBLE
        if (instant) {
            scrim.alpha = 1f
            panel.translationX = 0f
            focusStart()
            return
        }
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(220).start()
        val off = (panelW + margin).toFloat()
        panel.translationX = off
        panel.animate().translationX(0f).setDuration(320)
            .setInterpolator(android.view.animation.DecelerateInterpolator(2f))
            .setUpdateListener { invalidateDeep(panel) }
            .withEndAction { invalidateDeep(panel) }
            .start()
        focusStart()
    }

    fun close(instant: Boolean = false, after: (() -> Unit)? = null) {
        if (!isOpen) return
        isOpen = false
        if (instant) {
            visibility = View.GONE
            act.onSettingsClosed()
            after?.invoke()
            return
        }
        val off = (panelW + margin).toFloat()
        scrim.animate().alpha(0f).setDuration(200).start()
        panel.animate().translationX(off).setDuration(220)
            .setInterpolator(android.view.animation.AccelerateInterpolator(1.5f))
            .setUpdateListener { invalidateDeep(panel) }
            .withEndAction {
                visibility = View.GONE
                act.onSettingsClosed()
                after?.invoke()
            }.start()
    }
}

class AppMenu(private val act: HomeScreen) : FrameLayout(act.ctx) {
    var isOpen = false
        private set

    private var currentAnchor: View? = null
    private var onClosed: (() -> Unit)? = null

    // Scrim oscuro que difumina la pantalla y deja un recorte exacto sobre la app que tiembla
    private inner class AppMenuScrim(ctx: Context) : View(ctx) {
        var holeRect: RectF? = null
        var holeRadius = 0f
        private val path = Path()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCC060810.toInt() // 80% de oscurecimiento obsidiana
        }

        init {
            isClickable = true
            isFocusable = false
            setOnClickListener { close() }
        }

        override fun onDraw(canvas: Canvas) {
            val hr = holeRect
            if (hr != null) {
                path.reset()
                path.fillType = Path.FillType.EVEN_ODD
                path.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
                path.addRoundRect(hr, holeRadius, holeRadius, Path.Direction.CW)
                canvas.drawPath(path, paint)
            } else {
                canvas.drawColor(0xCC060810.toInt())
            }
        }
    }

    private val scrim = AppMenuScrim(context)

    // Panel opaco de alta densidad: 0% transparencia de lo que este detras
    val panel = GlassBox(context, dp(22f)).apply {
        glass.tint = 0.04f
        glass.dark = 0.94f
        glass.sheen = 0.20f
        glass.highlight = 0.70f
        glass.border = 0.30f
        shadowAlpha = 0.90f
        clipChildren = false
        clipToPadding = false
    }

    private val list = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        clipChildren = false
        clipToPadding = false
        setBackgroundColor(0xF4141722.toInt()) // Base solida que impide ver apps traseras
    }

    private val title = TextView(context).apply {
        textSize = 15f
        typeface = Typeface.create(Fonts.regular, Typeface.BOLD)
        setTextColor(0xFFFFFFFF.toInt())
        gravity = Gravity.START
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }

    private val bubbleW get() = dpi(235f)

    init {
        visibility = View.GONE
        clipChildren = false
        clipToPadding = false
        addView(scrim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        val pad = dpi(14f)
        list.setPadding(pad, dpi(12f), pad, dpi(12f))
        panel.addView(list, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(panel, LayoutParams(bubbleW, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
    }

    fun open(heading: String, items: List<Pair<String, () -> Unit>>, anchor: View? = null, closed: () -> Unit) {
        if (isOpen) return
        isOpen = true
        onClosed = closed
        currentAnchor = anchor

        list.removeAllViews()

        title.text = heading
        title.setPadding(dpi(6f), dpi(2f), dpi(6f), dpi(8f))
        list.addView(title, LinearLayout.LayoutParams(-1, -2))

        val div = View(context).apply { setBackgroundColor(0x33FFFFFF) }
        list.addView(div, LinearLayout.LayoutParams(-1, dpi(1f)).apply {
            bottomMargin = dpi(6f)
            leftMargin = dpi(4f)
            rightMargin = dpi(4f)
        })

        var first: View? = null
        for ((label, action) in items) {
            val row = RowView(context, label).apply {
                titleView.textSize = 14f
                titleView.gravity = Gravity.START
                valueView.visibility = View.GONE
            }
            row.onClick = { close { action() } }
            list.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(40f)).apply {
                bottomMargin = dpi(4f)
            })
            if (first == null) first = row
        }

        panel.measure(
            MeasureSpec.makeMeasureSpec(bubbleW, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        )
        val bubbleH = panel.measuredHeight

        val sw = Backdrop.screenW.takeIf { it > 0 } ?: context.resources.displayMetrics.widthPixels
        val sh = Backdrop.screenH.takeIf { it > 0 } ?: context.resources.displayMetrics.heightPixels

        if (anchor != null) {
            (anchor as? TileView)?.setJiggle(true, gentle = false)

            // Obtencion milimetrica de las coordenadas reales en pantalla
            val rect = Rect()
            anchor.getGlobalVisibleRect(rect)
            val left = rect.left.toFloat()
            val top = rect.top.toFloat()
            val right = rect.right.toFloat()
            val bottom = rect.bottom.toFloat()

            scrim.holeRect = RectF(left, top, right, bottom)
            scrim.holeRadius = resources.displayMetrics.density * 13f
            scrim.invalidate()

            val gap = dpi(16f)
            val placeRight = (right + bubbleW + gap) <= (sw - dpi(24f))
            val bX = if (placeRight) (right + gap) else (left - bubbleW - gap).coerceAtLeast(dpi(24f).toFloat())

            val aCenterY = rect.exactCenterY()
            var bY = aCenterY - (bubbleH / 2f)
            val minY = dpi(24f).toFloat()
            val maxY = (sh - bubbleH - dpi(24f)).toFloat()
            bY = bY.coerceIn(minY, maxY)

            panel.x = bX
            panel.y = bY
            panel.pivotX = if (placeRight) 0f else bubbleW.toFloat()
            panel.pivotY = (aCenterY - bY).coerceIn(0f, bubbleH.toFloat())
        } else {
            scrim.holeRect = null
            scrim.invalidate()
            panel.x = ((sw - bubbleW) / 2f).coerceAtLeast(0f)
            panel.y = ((sh - bubbleH) / 2f).coerceAtLeast(0f)
            panel.pivotX = bubbleW / 2f
            panel.pivotY = bubbleH / 2f
        }

        visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().cancel()
        scrim.animate().alpha(1f).setDuration(220L).start()

        // Inflado liquido tipo burbuja elastica
        panel.scaleX = 0f
        panel.scaleY = 0f
        panel.alpha = 0f
        panel.animate().cancel()
        panel.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(280L)
            .setInterpolator(OvershootInterpolator(1.35f))
            .withEndAction { invalidateDeep(panel) }
            .start()

        first?.requestFocus()
        invalidateDeep(panel)
    }

    // Efecto de absorcion ("se chupe solita") hacia el origen de la app
    fun close(instant: Boolean = false, after: (() -> Unit)? = null) {
        if (!isOpen) { after?.invoke(); return }
        isOpen = false
        val c = onClosed
        onClosed = null
        val targetAnchor = currentAnchor
        currentAnchor = null

        if (act.prefs.sound) HomeShare.sound(context)?.folderClose()

        if (instant) {
            panel.animate().cancel()
            scrim.animate().cancel()
            (targetAnchor as? TileView)?.setJiggle(false)
            visibility = View.GONE
            c?.invoke()
            after?.invoke()
            return
        }

        scrim.animate().cancel()
        scrim.animate().alpha(0f).setDuration(170L).start()

        panel.animate().cancel()
        panel.animate()
            .scaleX(0f)
            .scaleY(0f)
            .alpha(0f)
            .setDuration(200L)
            .setInterpolator(AccelerateInterpolator(1.8f))
            .withEndAction {
                (targetAnchor as? TileView)?.setJiggle(false)
                visibility = View.GONE
                c?.invoke()
                after?.invoke()
            }
            .start()
    }
}