package io.github.abhishekkaisar.glassos

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Test only: counts what the apps publish in Android TV's Watch Next list and says it in a message. */
object WatchNextProbe {
    @Volatile private var done = false

    fun run(ctx: Context) {
        if (done) return
        done = true
        val app = ctx.applicationContext
        Thread {
            val msg = try {
                val counts = LinkedHashMap<String, Int>()
                app.contentResolver.query(Uri.parse("content://android.media.tv/watch_next_program"),
                    arrayOf("package_name", "title"), null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val p = c.getString(0) ?: "?"
                        counts[p] = (counts[p] ?: 0) + 1
                    }
                }
                if (counts.isEmpty()) "Watch Next: empty" else "Watch Next: " + counts.entries.joinToString(", ") { it.key + " " + it.value }
            } catch (e: SecurityException) {
                "Watch Next: no permission"
            } catch (e: Throwable) {
                "Watch Next: " + (e.message ?: e.javaClass.simpleName)
            }
            Handler(Looper.getMainLooper()).post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }
}