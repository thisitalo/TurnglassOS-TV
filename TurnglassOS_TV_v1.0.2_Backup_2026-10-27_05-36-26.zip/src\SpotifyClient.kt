package io.github.abhishekkaisar.glassos

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One track from Spotify. */
class SpotTrack(val id: String, val name: String, val artist: String, val album: String, val artUrl: String?, val uri: String)

/** Talks to the Spotify Web API with the login the PC script saved in assets/spotify.json. */
object SpotifyClient {
    private const val PREFS = "glass_spotify"
    @Volatile var lastError = ""
    @Volatile private var token: String? = null
    @Volatile private var tokenUntil = 0L

    private fun login(ctx: Context): Pair<String, String>? {
        val j = try {
            JSONObject(ctx.assets.open("spotify.json").bufferedReader().use { it.readText() })
        } catch (e: Throwable) {
            lastError = "no login saved"
            return null
        }
        val id = j.optString("client_id")
        val origin = j.optString("refresh_token")
        if (id.isEmpty() || origin.isEmpty()) {
            lastError = "login file is empty"
            return null
        }
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = if (p.getString("origin", null) == origin) (p.getString("current", null) ?: origin) else origin
        return Pair(id, current)
    }

    @Synchronized
    fun accessToken(ctx: Context): String? {
        val now = System.currentTimeMillis()
        val have = token
        if (have != null && now < tokenUntil) return have
        val (id, refresh) = login(ctx) ?: return null
        val body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8") + "&client_id=" + URLEncoder.encode(id, "UTF-8")
        val c = URL("https://accounts.spotify.com/api/token").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode != 200) {
                lastError = "token HTTP " + c.responseCode
                return null
            }
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            token = j.getString("access_token")
            tokenUntil = now + (j.optLong("expires_in", 3600L) - 60L) * 1000L
            val fresh = j.optString("refresh_token")
            if (fresh.isNotEmpty()) {
                val origin = JSONObject(ctx.assets.open("spotify.json").bufferedReader().use { it.readText() }).optString("refresh_token")
                ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("origin", origin).putString("current", fresh).apply()
            }
            return token
        } finally {
            c.disconnect()
        }
    }

    private fun api(ctx: Context, path: String): Pair<Int, String>? {
        val t = accessToken(ctx) ?: return null
        val c = URL("https://api.spotify.com/v1$path").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("Authorization", "Bearer $t")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = try { stream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Throwable) { "" }
            if (code !in 200..299) lastError = "HTTP " + code + " " + text.take(100)
            return Pair(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun track(o: JSONObject): SpotTrack? {
        val id = o.optString("id")
        if (id.isEmpty()) return null
        val artists = o.optJSONArray("artists")
        val artist = if (artists != null && artists.length() > 0) artists.getJSONObject(0).optString("name") else ""
        val album = o.optJSONObject("album")
        val imgs = album?.optJSONArray("images")
        var art: String? = null
        if (imgs != null && imgs.length() > 0) art = imgs.getJSONObject(if (imgs.length() > 1) 1 else 0).optString("url")
        return SpotTrack(id, o.optString("name"), artist, album?.optString("name") ?: "", art, o.optString("uri"))
    }

    /** The last tracks played on the account, newest first, without repeats. Null when Spotify said no. */
    fun recent(ctx: Context, n: Int = 20): List<SpotTrack>? {
        val r = api(ctx, "/me/player/recently-played?limit=$n") ?: return null
        if (r.first != 200) return null
        val items = JSONObject(r.second).optJSONArray("items") ?: return emptyList()
        val out = ArrayList<SpotTrack>()
        val seen = HashSet<String>()
        for (i in 0 until items.length()) {
            val t = track(items.getJSONObject(i).optJSONObject("track") ?: continue) ?: continue
            if (seen.add(t.id)) out.add(t)
        }
        return out
    }

    /** What plays now on any device of the account, and whether it is playing or paused. Null when nothing. */
    fun nowPlaying(ctx: Context): Pair<SpotTrack, Boolean>? {
        val r = api(ctx, "/me/player/currently-playing") ?: return null
        if (r.first != 200 || r.second.isEmpty()) return null
        val j = JSONObject(r.second)
        val t = track(j.optJSONObject("item") ?: return null) ?: return null
        return Pair(t, j.optBoolean("is_playing", false))
    }
}

/** Test only: says in a message what Spotify returns for the saved login. */
object SpotifyProbe {
    @Volatile private var done = false

    fun run(ctx: Context) {
        if (done) return
        done = true
        val app = ctx.applicationContext
        Thread {
            SpotifyClient.lastError = ""
            val msg = try {
                val recent = SpotifyClient.recent(app)
                val now = SpotifyClient.nowPlaying(app)
                if (recent == null && now == null) "Spotify: " + SpotifyClient.lastError.ifEmpty { "no answer" }
                else if (now != null && now.second) "Spotify now playing: " + now.first.name + " - " + now.first.artist
                else if (recent != null && recent.isNotEmpty()) "Spotify last played: " + recent[0].name + " - " + recent[0].artist + " (" + recent.size + " recent)"
                else "Spotify connected, but no recent tracks yet"
            } catch (e: Throwable) {
                "Spotify: " + (e.message ?: e.javaClass.simpleName)
            }
            Handler(Looper.getMainLooper()).post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }
}