package io.github.abhishekkaisar.glassos

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random

class EqualizerBars(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1DB954.toInt() }
    private val heights = floatArrayOf(0.4f, 0.8f, 0.5f, 0.9f)
    private val targets = floatArrayOf(0.4f, 0.8f, 0.5f, 0.9f)
    private val rnd = Random()
    var isPlaying = false
        set(v) {
            if (field != v) {
                field = v
                if (v) postInvalidateOnAnimation() else invalidate()
            }
        }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        if (isPlaying) {
            val barW = w / 6.5f
            val gap = barW * 0.6f

            for (i in 0 until 4) {
                val barH = (h * heights[i]).coerceAtLeast(barW)
                val left = i * (barW + gap)
                val top = h - barH
                val rect = RectF(left, top, left + barW, h)
                canvas.drawRoundRect(rect, barW / 2, barW / 2, paint)
            }

            for (i in 0 until 4) {
                heights[i] += (targets[i] - heights[i]) * 0.28f
                if (Math.abs(targets[i] - heights[i]) < 0.06f) {
                    targets[i] = 0.20f + rnd.nextFloat() * 0.80f
                }
            }
            postInvalidateOnAnimation()
        } else {
            val barW = w * 0.22f
            val gap = w * 0.24f
            val totalW = 2 * barW + gap
            val startX = (w - totalW) / 2f
            val top = h * 0.12f
            val bottom = h * 0.88f

            canvas.drawRoundRect(RectF(startX, top, startX + barW, bottom), barW / 2, barW / 2, paint)
            canvas.drawRoundRect(RectF(startX + barW + gap, top, startX + 2 * barW + gap, bottom), barW / 2, barW / 2, paint)
        }
    }
}

class DynamicIslandView(private val ctx: Context, private val host: HomeScreen) : FrameLayout(ctx) {
    private val ui = Handler(Looper.getMainLooper())
    var isPlaying = false
        private set
    var isAmbient = false
        private set
    private var currentPkg: String? = null
    private var watched: MediaController? = null

    private val sessionCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            ui.post { checkActiveSession() }
        }
        override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
            ui.post { checkActiveSession() }
        }
        override fun onSessionDestroyed() {
            ui.post { checkActiveSession() }
        }
    }

    private val artView = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setImageResource(android.R.drawable.ic_media_play)
        setColorFilter(0xFF1DB954.toInt())
    }

    private val titleView = TextView(ctx).apply {
        setTextColor(0xFFFFFFFF.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
        typeface = android.graphics.Typeface.create(Fonts.regular, android.graphics.Typeface.BOLD)
        isSingleLine = true
        ellipsize = TextUtils.TruncateAt.MARQUEE
        marqueeRepeatLimit = -1
        isSelected = true
        includeFontPadding = false
        maxWidth = ctx.dpi(190f)
    }

    private val artistView = TextView(ctx).apply {
        setTextColor(0xB3FFFFFF.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        typeface = Fonts.regular
        isSingleLine = true
        ellipsize = TextUtils.TruncateAt.END
        includeFontPadding = false
        maxWidth = ctx.dpi(190f)
    }

    private val eq = EqualizerBars(ctx)

    val pill: LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val r = ctx.dpi(18f).toFloat()

        val normalBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
            setColor(0xF012141A.toInt())
            setStroke(ctx.dpi(1.5f), 0x38FFFFFF.toInt())
        }

        val focusedBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
            setColor(0xF0181C26.toInt())
            setStroke(ctx.dpi(2.5f), 0xFF1DB954.toInt())
        }

        background = normalBg

        val padH = ctx.dpi(14f)
        val padV = ctx.dpi(7f)
        setPadding(padH, padV, padH, padV)
        clipChildren = false
        clipToPadding = false

        val artSize = ctx.dpi(24f)
        addView(artView, LinearLayout.LayoutParams(artSize, artSize).apply { rightMargin = ctx.dpi(10f) })

        val textCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView, LinearLayout.LayoutParams(-2, -2))
            addView(artistView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ctx.dpi(2f) })
        }
        addView(textCol, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = ctx.dpi(12f) })

        val eqW = ctx.dpi(16f)
        val eqH = ctx.dpi(14f)
        addView(eq, LinearLayout.LayoutParams(eqW, eqH))

        isFocusable = true
        isClickable = true

        onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                background = focusedBg
                animate().scaleX(1.06f).scaleY(1.06f).setDuration(160L).start()
            } else {
                background = normalBg
                animate().scaleX(1.0f).scaleY(1.0f).setDuration(160L).start()
            }
        }

        setOnClickListener {
            togglePlayPause()
        }
    }

    private val spotifyReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            intent ?: return
            val playing = intent.getBooleanExtra("playing", false)
            val track = intent.getStringExtra("track") ?: ""
            val artist = intent.getStringExtra("artist") ?: ""
            if (track.isNotEmpty()) {
                updateState(track, artist, null, playing, "com.spotify.tv.android")
            }
        }
    }

    private val poller = object : Runnable {
        override fun run() {
            checkActiveSession()
            ui.postDelayed(this, 2500L)
        }
    }

    init {
        visibility = View.GONE
        alpha = 0f
        scaleX = 0.85f
        scaleY = 0.85f
        clipChildren = false
        clipToPadding = false

        addView(pill, LayoutParams(-2, -2, Gravity.CENTER))

        try {
            val filter = IntentFilter().apply {
                addAction("com.spotify.music.playbackstatechanged")
                addAction("com.spotify.music.metadatachanged")
                addAction("com.spotify.music.queuechanged")
            }
            ctx.registerReceiver(spotifyReceiver, filter)
        } catch (e: Throwable) { }
    }

    // Calcula el desplazamiento exacto para posarse en la esquina superior derecha
    private fun targetShiftX(): Float {
        val curW = (if (pill.width > 0) pill.width else width).takeIf { it > 0 } ?: ctx.dpi(240f).toInt()
        return (Backdrop.screenW / 2f) - (Backdrop.screenW * 60f / 1920f) - (curW / 2f)
    }

    private fun targetShiftY(): Float = Backdrop.screenH * 14f / 1080f

    fun enterAmbient() {
        isAmbient = true
        if (visibility != View.VISIBLE) return
        pill.post {
            animate().cancel()
            animate()
                .translationX(targetShiftX())
                .translationY(targetShiftY())
                .setDuration(900L)
                .setInterpolator(DecelerateInterpolator(1.8f))
                .start()
        }
    }

    fun exitAmbient() {
        isAmbient = false
        if (visibility != View.VISIBLE) {
            translationX = 0f
            translationY = 0f
            return
        }
        animate().cancel()
        animate()
            .translationX(0f)
            .translationY(0f)
            .setDuration(350L)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    fun togglePlayPause() {
        val np = NowPlaying.current(ctx)
        val controller = np?.controller ?: watched
        if (controller != null) {
            val tc = controller.transportControls
            val isNowPlaying = np?.playing ?: isPlaying
            if (isNowPlaying) {
                tc.pause()
                setPlayingState(false)
            } else {
                tc.play()
                setPlayingState(true)
            }
        } else {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
            am?.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            am?.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            setPlayingState(!isPlaying)
        }
    }

    private fun setPlayingState(playing: Boolean) {
        isPlaying = playing
        eq.isPlaying = playing
    }

    fun checkActiveSession() {
        val np = NowPlaying.current(ctx)
        if (np != null) {
            watchSession(np.controller)
            updateState(np.title, np.subtitle, np.art, np.playing, np.pkg)
        } else {
            unwatchSession()
            if (!isPlaying) {
                hide()
            }
        }
    }

    private fun watchSession(controller: MediaController) {
        if (watched === controller) return
        unwatchSession()
        watched = controller
        try { controller.registerCallback(sessionCb, ui) } catch (e: Throwable) { }
    }

    private fun unwatchSession() {
        try { watched?.unregisterCallback(sessionCb) } catch (e: Throwable) { }
        watched = null
    }

    fun updateState(title: String, artist: String, art: Bitmap?, playing: Boolean, pkg: String?) {
        currentPkg = pkg
        setPlayingState(playing)

        titleView.text = title
        artistView.text = if (artist.isEmpty()) "Spotify" else artist

        if (art != null) {
            artView.clearColorFilter()
            artView.setImageBitmap(art)
        } else {
            artView.setImageResource(android.R.drawable.ic_media_play)
            artView.setColorFilter(0xFF1DB954.toInt())
        }

        show()

        if (isAmbient || host.ambientActive) {
            pill.post {
                animate().cancel()
                animate()
                    .translationX(targetShiftX())
                    .translationY(targetShiftY())
                    .setDuration(400L)
                    .setInterpolator(DecelerateInterpolator(1.8f))
                    .start()
            }
        }
    }

    fun show() {
        if (isAmbient || host.ambientActive) {
            translationX = targetShiftX()
            translationY = targetShiftY()
        } else {
            translationX = 0f
            translationY = 0f
        }

        if (visibility == View.VISIBLE && alpha > 0.9f) return
        visibility = View.VISIBLE
        animate().cancel()
        animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(260L)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    fun hide() {
        if (visibility != View.VISIBLE) return
        animate().cancel()
        animate().alpha(0f).scaleX(0.85f).scaleY(0.85f)
            .setDuration(200L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction { visibility = View.GONE }
            .start()
    }

    fun onResume() {
        ui.removeCallbacks(poller)
        ui.post(poller)
    }

    fun onPause() {
        ui.removeCallbacks(poller)
    }

    fun release() {
        ui.removeCallbacks(poller)
        unwatchSession()
        try { ctx.unregisterReceiver(spotifyReceiver) } catch (e: Throwable) { }
    }
}