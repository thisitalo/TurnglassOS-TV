package io.github.abhishekkaisar.glassos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

class Wallpaper(val sharp: Bitmap, val blurred: Bitmap)

object WallpaperStore {
    private const val GEN = 15
    val scenes = listOf(
        "scene:nostalgia" to "Nostalgia PS",
        "scene:liquid" to "Liquid Glass",
        "scene:desert" to "Night desert",
        "scene:ocean" to "Dusk ocean",
        "scene:aurora" to "Aurora",
        "scene:dark" to "Dark"
    )

    fun userDir(): File = File(Environment.getExternalStorageDirectory(), "Pictures/Glass")

    fun userImages(): List<File> {
        val exts = setOf("jpg", "jpeg", "png", "webp")
        return try {
            userDir().listFiles()?.filter { it.isFile && it.extension.lowercase() in exts && !it.name.lowercase().contains("liquid") }?.sortedBy { it.name.lowercase() } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    val heroModes = listOf(HeroRepo.PHOTOS to "My photos")

    fun label(id: String): String =
        heroModes.firstOrNull { it.first == id }?.second ?:
        scenes.firstOrNull { it.first == id }?.second ?: File(id.removePrefix("file:")).nameWithoutExtension.replace('_', ' ')

    fun renderDarkThumb(w: Int, h: Int, isPs: Boolean): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(0xFF06080F.toInt())
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.4f
            color = if (isPs) 0xCC00D2FF.toInt() else 0xCCF59E0B.toInt()
        }
        val y1 = h * 0.42f
        val y2 = h * 0.58f
        c.drawLine(0f, y1 + 10f, w.toFloat(), y1 - 10f, line)
        c.drawLine(0f, y2 - 8f, w.toFloat(), y2 + 8f, line)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        c.drawCircle(w * 0.45f, y1, 3.2f, dot)
        c.drawCircle(w * 0.72f, y2, 2.8f, dot)
        return b
    }

    fun load(ctx: Context, id: String, w: Int, h: Int): Wallpaper {
        if (id == "scene:nostalgia" || id == "scene:liquid") {
            val sharp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val blurred = Blur.makeBackdrop(sharp)
            return Wallpaper(sharp, blurred)
        }
        val sharp = if (id.startsWith("file:")) decodeCrop(File(id.removePrefix("file:")), w, h) ?: scene(ctx, "desert", w, h)
        else scene(ctx, id.removePrefix("scene:"), w, h)
        val blurFile = File(ctx.filesDir, "blur_${key(id)}_${GEN}_${w}x$h.png")
        val cached = if (blurFile.exists() && !id.startsWith("file:")) BitmapFactory.decodeFile(blurFile.path) else null
        val blurred = cached ?: Blur.makeBackdrop(sharp).also { b ->
            if (!id.startsWith("file:")) save(b, blurFile, Bitmap.CompressFormat.PNG)
        }
        return Wallpaper(sharp, blurred)
    }

    private fun key(id: String) = id.replace(Regex("[^A-Za-z0-9]"), "_").takeLast(60)

    private fun scene(ctx: Context, name: String, w: Int, h: Int): Bitmap {
        val f = File(ctx.filesDir, "wall_${name}_${GEN}_${w}x$h.png")
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return it }
        val b = WallpaperGen.render(name, w, h)
        save(b, f, Bitmap.CompressFormat.PNG)
        return b
    }

    private fun save(b: Bitmap, f: File, fmt: Bitmap.CompressFormat) {
        try {
            val tmp = File(f.path + ".tmp")
            FileOutputStream(tmp).use { b.compress(fmt, 100, it) }
            tmp.renameTo(f)
        } catch (e: Exception) { }
    }

    fun thumb(ctx: Context, id: String, w: Int, h: Int): Bitmap? {
        if (id == "scene:nostalgia" || id == "scene:liquid") return renderDarkThumb(w, h, id == "scene:nostalgia")
        if (id.startsWith("file:")) return decodeCrop(File(id.removePrefix("file:")), w, h)
        val name = id.removePrefix("scene:")
        val tf = File(ctx.filesDir, "thumb_${name}_${GEN}_${w}x$h.png")
        if (tf.exists()) BitmapFactory.decodeFile(tf.path)?.let { return it }
        val b = WallpaperGen.render(name, w * 2, h * 2)
        val t = Bitmap.createScaledBitmap(b, w, h, true)
        b.recycle()
        save(t, tf, Bitmap.CompressFormat.PNG)
        return t
    }

    fun decodeCrop(f: File, w: Int, h: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var sample = 1
            while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) sample *= 2
            val src = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
            val scale = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
            val cw = (w / scale).toInt()
            val ch = (h / scale).toInt()
            val sx = (src.width - cw) / 2
            val sy = (src.height - ch) / 2
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(src, Rect(sx, sy, sx + cw, sy + ch), Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
            src.recycle()
            out.setHasAlpha(false)
            out
        } catch (e: Throwable) { null }
    }
}