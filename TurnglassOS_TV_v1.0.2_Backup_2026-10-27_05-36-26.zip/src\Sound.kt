package io.github.abhishekkaisar.glassos

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class Sound(ctx: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(5)
        .setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .build()

    private val ready = java.util.Collections.synchronizedSet(HashSet<Int>())
    private var tickId = 0
    private var cardId = 0
    private var closeId = 0
    private var modalId = 0
    private var last = 0L

    init {
        val fTick = File(ctx.cacheDir, "tick_crystal_v2.wav")
        if (!fTick.exists()) writeTick(fTick)
        val fCard = File(ctx.cacheDir, "card_deal_v1.wav")
        if (!fCard.exists()) writeCardDeal(fCard)
        val fClose = File(ctx.cacheDir, "folder_close_v2.wav")
        if (!fClose.exists()) writeFolderClose(fClose)
        val fModal = File(ctx.cacheDir, "modal_tone_v1.wav")
        if (!fModal.exists()) writeModalTone(fModal)

        pool.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) ready.add(sampleId) }
        tickId = pool.load(fTick.path, 1)
        cardId = pool.load(fCard.path, 1)
        closeId = pool.load(fClose.path, 1)
        modalId = pool.load(fModal.path, 1)
    }

    private fun play(id: Int, vol: Float) {
        if (id == 0 || !ready.contains(id)) return
        pool.play(id, vol, vol, 1, 0, 1f)
    }

    fun tick() {
        val now = System.currentTimeMillis()
        if (now - last < 32) return
        last = now
        play(tickId, 0.42f)
    }

    fun cardDeal() = play(cardId, 0.65f)
    fun folderClose() = play(closeId, 0.58f)
    fun modalOpen() = play(modalId, 0.48f)
    fun release() = pool.release()

    private fun writeWav(f: File, audio: DoubleArray, peak: Int) {
        val rate = 44100
        val n = audio.size
        val data = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in audio) data.putShort((s.coerceIn(-1.0, 1.0) * peak).toInt().toShort())
        val hdr = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        hdr.put("RIFF".toByteArray()); hdr.putInt(36 + n * 2); hdr.put("WAVE".toByteArray())
        hdr.put("fmt ".toByteArray()); hdr.putInt(16); hdr.putShort(1); hdr.putShort(1)
        hdr.putInt(rate); hdr.putInt(rate * 2); hdr.putShort(2); hdr.putShort(16)
        hdr.put("data".toByteArray()); hdr.putInt(n * 2)
        FileOutputStream(f).use { it.write(hdr.array()); it.write(data.array()) }
    }

    private fun writeCardDeal(f: File) {
        val rate = 44100
        val n = (rate * 0.32).toInt()
        val rnd = java.util.Random(99)
        val audio = DoubleArray(n)
        for (idx in 0 until 8) {
            val startSample = (idx * 0.032 * rate).toInt()
            val cardLen = (rate * 0.045).toInt()
            for (i in 0 until cardLen) {
                val sIdx = startSample + i
                if (sIdx >= n) break
                val t = i / rate.toDouble()
                val freq = 720.0 + idx * 55.0
                val noise = (rnd.nextDouble() - 0.5) * 2.0 * exp(-t * 260.0)
                val tap = sin(2 * PI * freq * t) * exp(-t * 190.0)
                val attack = 1.0 - exp(-t * 2800.0)
                audio[sIdx] += (noise * 0.65 + tap * 0.35) * attack * 0.75
            }
        }
        writeWav(f, audio, 26000)
    }

    private fun writeTick(f: File) {
        val rate = 44100
        val n = (rate * 0.055).toInt()
        val rnd = java.util.Random(42)
        val audio = DoubleArray(n)
        for (i in 0 until n) {
            val t = i / rate.toDouble()
            val env = exp(-t * 110.0) * (1.0 - exp(-t * 12000.0))
            val glass = sin(2 * PI * 2400 * t) * 0.48 +
                        sin(2 * PI * 4800 * t) * 0.24 +
                        sin(2 * PI * 7200 * t) * 0.12 +
                        sin(2 * PI * 9600 * t) * 0.06 +
                        (rnd.nextDouble() - 0.5) * 0.10 * exp(-t * 800.0)
            audio[i] = glass * env
        }
        writeWav(f, audio, 28000)
    }

    private fun writeFolderClose(f: File) {
        val rate = 44100
        val n = (rate * 0.19).toInt()
        val rnd = java.util.Random(19)
        val audio = DoubleArray(n)
        for (i in 0 until n) {
            val t = i / rate.toDouble()
            val env = (1.0 - exp(-t * 400.0)) * exp(-t * 22.0)
            val freq = 210.0 - (120.0 * (t / 0.19))
            val body = sin(2 * PI * freq * t) * 0.70 + sin(2 * PI * (freq * 0.5) * t) * 0.30
            val airNoise = (rnd.nextDouble() - 0.5) * 0.15 * exp(-t * 35.0)
            audio[i] = (body + airNoise) * env
        }
        writeWav(f, audio, 27000)
    }

    private fun writeModalTone(f: File) {
        val rate = 44100
        val n = (rate * 0.14).toInt()
        val audio = DoubleArray(n)
        for (i in 0 until n) {
            val t = i / rate.toDouble()
            val env = (1.0 - exp(-t * 600.0)) * exp(-t * 28.0)
            val tone = sin(2 * PI * 523.25 * t) * 0.65 + sin(2 * PI * 1046.5 * t) * 0.35
            audio[i] = tone * env
        }
        writeWav(f, audio, 24000)
    }
}