package io.github.abhishekkaisar.glassos

import android.animation.ValueAnimator
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Color
import android.view.animation.AccelerateDecelerateInterpolator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** A small drawn weather icon: sun, moon, clouds, rain, snow, thunder or fog. */
class WeatherIcon(ctx: Context, private val side: Int) : View(ctx) {
    var code = 0
        set(v) { field = v; invalidate() }
    var day = true
        set(v) { field = v; invalidate() }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private var breath = 0f
    private val breathAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600L
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            breath = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        breathAnim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        breathAnim.cancel()
    }
    private val path = Path()
    private val cut = Path()

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(side, side)

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xFFFFC83D.toInt()
                val haloAlpha = (26 + 32 * breath).toInt()
        halo.shader = RadialGradient(cx, cy, r * 1.35f,
            intArrayOf(Color.argb(haloAlpha, 255, 200, 60), 0),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.35f, halo)
        c.drawCircle(cx, cy, r * 0.5f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.14f
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 8) {
            val a = i * PI.toFloat() / 4f
            c.drawLine(cx + cos(a) * r * 0.72f, cy + sin(a) * r * 0.72f, cx + cos(a) * r * 0.95f, cy + sin(a) * r * 0.95f, p)
        }
    }

    private fun moon(c: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        cut.reset()
        path.addCircle(cx, cy, r * 0.7f, Path.Direction.CW)
        cut.addCircle(cx + r * 0.36f, cy - r * 0.26f, r * 0.58f, Path.Direction.CW)
        path.op(cut, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = 0xFFEDEDF2.toInt()
        c.drawPath(path, p)
    }

    private fun cloud(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(cx - s * 0.28f, cy + s * 0.05f, s * 0.26f, p)
        c.drawCircle(cx + s * 0.02f, cy - s * 0.12f, s * 0.32f, p)
        c.drawCircle(cx + s * 0.32f, cy + s * 0.06f, s * 0.24f, p)
        c.drawRoundRect(cx - s * 0.55f, cx.let { cy + s * 0.02f }, cx + s * 0.56f, cy + s * 0.30f, s * 0.14f, s * 0.14f, p)
    }

    private fun lineP(color: Int, w: Float) {
        p.style = Paint.Style.STROKE
        p.color = color
        p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        val s = side.toFloat()
        val cx = s / 2f
        val cy = s / 2f
        val white = 0xF2FFFFFF.toInt()
        when {
            code == 0 -> if (day) sun(c, cx, cy, s * 0.5f) else moon(c, cx, cy, s * 0.5f)
            code == 1 || code == 2 -> {
                if (day) sun(c, cx - s * 0.14f, cy - s * 0.16f, s * 0.36f) else moon(c, cx - s * 0.14f, cy - s * 0.16f, s * 0.36f)
                cloud(c, cx + s * 0.06f, cy + s * 0.12f, s * 0.78f, white)
            }
            code == 3 -> cloud(c, cx, cy, s * 0.95f, white)
            code == 45 || code == 48 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.82f, 0xCCFFFFFF.toInt())
                lineP(0xCCFFFFFF.toInt(), s * 0.06f)
                c.drawLine(cx - s * 0.3f, cy + s * 0.28f, cx + s * 0.3f, cy + s * 0.28f, p)
                c.drawLine(cx - s * 0.2f, cy + s * 0.42f, cx + s * 0.2f, cy + s * 0.42f, p)
            }
            code in 51..67 || code in 80..82 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f, white)
                lineP(0xFF6CB8FF.toInt(), s * 0.07f)
                for (i in -1..1) {
                    val x = cx + i * s * 0.2f
                    c.drawLine(x, cy + s * 0.2f, x - s * 0.06f, cy + s * 0.42f, p)
                }
            }
            code in 71..77 || code == 85 || code == 86 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f, white)
                p.style = Paint.Style.FILL
                p.color = Color_WHITE
                for (i in -1..1) c.drawCircle(cx + i * s * 0.2f, cy + s * 0.34f, s * 0.045f, p)
            }
            code >= 95 -> {
                cloud(c, cx, cy - s * 0.14f, s * 0.85f, 0xFFD0D3DA.toInt())
                path.reset()
                path.moveTo(cx + s * 0.06f, cy + s * 0.08f)
                path.lineTo(cx - s * 0.08f, cy + s * 0.30f)
                path.lineTo(cx, cy + s * 0.30f)
                path.lineTo(cx - s * 0.07f, cy + s * 0.48f)
                path.lineTo(cx + s * 0.12f, cy + s * 0.24f)
                path.lineTo(cx + s * 0.03f, cy + s * 0.24f)
                path.close()
                p.style = Paint.Style.FILL
                p.color = 0xFFFFD60A.toInt()
                c.drawPath(path, p)
            }
            else -> cloud(c, cx, cy, s * 0.95f, white)
        }
    }

    private companion object {
        const val Color_WHITE = -1
    }
}

class Wx(val text: String, val code: Int, val day: Boolean, val temp: Int? = null)

/** Top left of the home, with no box: a small greeting, a big clock, the date and the weather with an icon. */
class WelcomeCard(private val ctx: Context, name: String?) {
    val view = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val greeting = TextView(ctx).also { style(it, 26f, 0xB3FFFFFF.toInt()) }
    private val clock = TextClock(ctx).also { style(it, 112f, 0xF2FFFFFF.toInt(), true) }
    private val date = TextView(ctx).also { style(it, 30f, 0xE6FFFFFF.toInt()) }
    private val icon = WeatherIcon(ctx, Backdrop.screenH * 46 / 1080)
    private val weather = TextView(ctx).also { style(it, 30f, 0xE6FFFFFF.toInt()) }
    private val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private val ui = Handler(Looper.getMainLooper())

    init {
        val gap = Backdrop.screenH * 4 / 1080
        row.addView(icon, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Backdrop.screenH * 12 / 1080 })
        row.addView(weather)
        view.addView(greeting)
        view.addView(clock, LinearLayout.LayoutParams(-2, -2).apply { topMargin = gap })
        view.addView(date, LinearLayout.LayoutParams(-2, -2).apply { topMargin = gap })
        view.addView(row, LinearLayout.LayoutParams(-2, -2).apply { topMargin = gap * 2 })
        row.visibility = View.GONE
        setName(name)
        applyClock()
    }

    private fun style(t: TextView, size: Float, color: Int, bold: Boolean = false) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, Backdrop.screenH * size / 1080f)
        t.typeface = if (bold) Typeface.create(Fonts.regular, Typeface.BOLD) else Fonts.regular
        t.setTextColor(color)
        t.setShadowLayer(ctx.dp(8f), 0f, ctx.dp(1f), 0x80000000.toInt())
        t.maxLines = 1
        t.includeFontPadding = false
    }

    fun setName(name: String?) {
        val who = name?.takeIf { it.isNotBlank() } ?: DEFAULT_NAME
        greeting.text = "Welcome back, $who"
    }

    /** 12 or 24 hours, as chosen with the Clock button of the quick panel. */
    fun applyClock() {
        val f = if (QuickPanel.use24(ctx)) "HH:mm" else "h:mm"
        clock.format12Hour = f
        clock.format24Hour = f
    }

    /** Updates the date and loads the weather when the last reading is older than 30 minutes. */
    fun refresh() {
        date.text = SimpleDateFormat("EEEE MMMM d", Locale.getDefault()).format(Date())
        cached?.let { show(it) }
        val now = SystemClock.elapsedRealtime()
        if (loading || (cachedAt != 0L && now - cachedAt < 30 * 60_000L)) return
        loading = true
        Thread {
            val t = try { fetch() } catch (e: Throwable) { null }
            loading = false
            if (t != null) {
                cached = t
                cachedAt = SystemClock.elapsedRealtime()
                ui.post { show(t) }
            }
        }.apply { priority = Thread.MIN_PRIORITY; isDaemon = true }.start()
    }

    private fun show(w: Wx) {
        weather.text = w.text
        icon.day = w.day
        icon.code = w.code
        row.visibility = View.VISIBLE
        view.invalidate()
    }

    private fun fetch(): Wx? {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code,is_day&timezone=auto")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            if (c.responseCode != 200) return null
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val cur = JSONObject(body).getJSONObject("current")
            val t = Math.round(cur.getDouble("temperature_2m")).toInt()
            val code = cur.getInt("weather_code")
            val day = cur.optInt("is_day", 1) == 1
            return Wx("$CITY  \u00B7  ${t}\u00B0  \u00B7  ${describe(code)}", code, day, t)
        } finally {
            c.disconnect()
        }
    }

    private fun describe(code: Int) = when (code) {
        0 -> "Clear"
        1 -> "Mostly Clear"
        2 -> "Partly Cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        85, 86 -> "Snow Showers"
        in 95..99 -> "Thunderstorm"
        else -> "Weather"
    }

    companion object {
        /** Change these to change the city of the weather. */
        const val LAT = "14.0723"
        const val LON = "-87.1921"
        const val CITY = "Tegucigalpa"
        const val DEFAULT_NAME = "Osorio"
        @Volatile var cached: Wx? = null
        @Volatile private var cachedAt = 0L
        @Volatile private var loading = false
    }
}