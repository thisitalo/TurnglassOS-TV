package io.github.abhishekkaisar.glassos

import android.app.usage.UsageStatsManager
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.AccelerateInterpolator
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL

/** Cards of the Continue row and the App Library: they say where they sit so the home can scroll to them. */
interface StackFocus { var stackY: Int }

/** One card of the Continue row: the cover art full bleed, the title and artist over a dark fade. */
class MediaCard(ctx: Context, private val cw: Int, private val chh: Int) : View(ctx), StackFocus {
    override var stackY = 0
    var onClick: (() -> Unit)? = null
    var onNav: ((Int) -> Boolean)? = null
    private var shownTitle = ""
    private var shownSub = ""
    private var tag = ""
    private val radius = ctx.dp(12.5f)
    private val focus = FocusAnim(this, 1.12f) { invalidate() }
    private val rect = RectF()
    private val artPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A3350.toInt() }
    private val topPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1ED760.toInt() }
    private val gp = Paint()
    private val m = Matrix()
    private val tt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Fonts.medium
        textSize = chh * 0.115f
        color = Color.WHITE
        setShadowLayer(ctx.dp(3f), 0f, ctx.dp(1f), 0x80000000.toInt())
    }
    private val st = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Fonts.regular
        textSize = chh * 0.09f
        color = 0xD9FFFFFF.toInt()
        setShadowLayer(ctx.dp(3f), 0f, ctx.dp(1f), 0x80000000.toInt())
    }
    private val gt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Fonts.medium
        textSize = chh * 0.075f
        color = 0xE6FFFFFF.toInt()
        setShadowLayer(ctx.dp(3f), 0f, ctx.dp(1f), 0x80000000.toInt())
    }

    init {
        isFocusable = true
        isClickable = true
        outlineProvider = null
        topPaint.shader = LinearGradient(0f, 0f, 0f, chh * 0.4f, 0x73000000, 0x00000000, Shader.TileMode.CLAMP)
        scrimPaint.shader = LinearGradient(0f, chh * 0.38f, 0f, chh.toFloat(), 0x00000000, 0xE6000000.toInt(), Shader.TileMode.CLAMP)
        rim.shader = LinearGradient(0f, 0f, 0f, chh.toFloat(),
            intArrayOf(alphaOf(Color.WHITE, 0.57f), alphaOf(Color.WHITE, 0.13f)), null, Shader.TileMode.CLAMP)
        setOnClickListener { onClick?.invoke() }
    }

    fun bind(t: SpotTrack, bmp: Bitmap?, label: String) {
        val maxW = cw - 2f * chh * 0.09f
        shownTitle = TextUtils.ellipsize(t.name, tt, maxW, TextUtils.TruncateAt.END).toString()
        shownSub = TextUtils.ellipsize(t.artist, st, maxW, TextUtils.TruncateAt.END).toString()
        tag = label
        if (bmp != null) {
            val s = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val sc = maxOf(cw / bmp.width.toFloat(), chh / bmp.height.toFloat())
            m.setScale(sc, sc)
            m.postTranslate((cw - bmp.width * sc) / 2f, (chh - bmp.height * sc) / 2f)
            s.setLocalMatrix(m)
            artPaint.shader = s
        } else {
            artPaint.shader = null
        }
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(cw, chh)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pivotX = cw / 2f
        pivotY = chh / 2f
    }

    override fun onFocusChanged(gained: Boolean, direction: Int, previous: Rect?) {
        super.onFocusChanged(gained, direction, previous)
        translationZ = if (gained) 2f else 0f
        focus.set(gained)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN ->
                if (onNav?.invoke(keyCode) == true) return true
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (!event.isCanceled) onClick?.invoke()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onDraw(c: Canvas) {
        val f = focus.amount
        val w = cw.toFloat()
        val h = chh.toFloat()
        rect.set(0f, 0f, w, h)
        val blur = Math.round((dp(10f) + dp(10f) * f) / 4f) * 4f
        GlowCache.draw(c, w, h, radius, blur, Color.BLACK, 0.30f + 0.40f * f, dp(3f) + dp(12f) * f, gp)
        c.drawRoundRect(rect, radius, radius, if (artPaint.shader != null) artPaint else bgPaint)
        c.drawRoundRect(rect, radius, radius, topPaint)
        c.drawRoundRect(rect, radius, radius, scrimPaint)

        if (f > 0.01f) {
            ring.strokeWidth = dp(0.75f)
            ring.color = alphaOf(0xFFD8D8DC.toInt(), 0.9f * f)
            val bs = ring.strokeWidth / 2
            c.drawRoundRect(bs, bs, w - bs, h - bs, radius - bs, radius - bs, ring)
        }
        rim.strokeWidth = dp(0.8f)
        rim.alpha = ((0.385f + 0.615f * f) * 255).toInt()
        val hs = rim.strokeWidth / 2
        c.drawRoundRect(hs, hs, w - hs, h - hs, radius - hs, radius - hs, rim)

        val pad = h * 0.09f
        c.drawText(shownSub, pad, h - pad, st)
        c.drawText(shownTitle, pad, h - pad - st.textSize * 1.3f, tt)
        val dr = h * 0.026f
        val ty = pad + gt.textSize * 0.8f
        c.drawCircle(pad + dr, ty - gt.textSize * 0.3f, dr, dot)
        c.drawText(tag, pad + dr * 2 + h * 0.03f, ty, gt)
    }
}

/** One group of the App Library: a name and its apps. */
class LibCat(val name: String, val apps: List<AppEntry>)

/** Sorts the installed apps into the App Library's groups: by name and label first, then by what Android says. */
object AppLibrary {
    private val NAMES = arrayOf("Suggestions", "Recently Added", "Social", "Creativity", "Entertainment", "Utilities",
        "Productivity", "Finance", "Business", "Travel", "Games", "Shopping & Food", "Information & Reading",
        "Health & Fitness", "Other")

    /** Group index and the words that put an app in it, most specific groups first. */
    private val RULES: Array<Pair<Int, Array<String>>> = arrayOf(
        10 to arrayOf("game", "retroarch", "moonlight", "geforcenow", "steam", "xbox", "playstation", "minecraft", "roblox", "emulator", "ppsspp"),
        4 to arrayOf("netflix", "youtube", "amazonvideo", "primevideo", "hbo", "wbd.stream", "disney", "hulu", "plex", "spotify",
            "appletv", "atve", "paramount", "peacock", "crunchyroll", "twitch", "vlc", "kodi", "smarttube", "tubi", "pluto",
            "jellyfin", "emby", "deezer", "tidal", "music", "video", "movie", "stream", "iptv", "cinema", "anime", "vix",
            "starplus", "hotstar", "dazn", "espn", "fubo", "sling", "vevo", "soundcloud"),
        2 to arrayOf("facebook", "instagram", "whatsapp", "telegram", "twitter", "tiktok", "snapchat", "discord", "linkedin",
            "reddit", "messenger", "pinterest", "skype", "viber", "wechat"),
        3 to arrayOf("photo", "camera", "gallery", "draw", "paint", "design", "canva", "photoshop", "lightroom", "editor", "sketch"),
        7 to arrayOf("bank", "banco", "paypal", "wallet", "finance", "crypto", "binance", "venmo"),
        8 to arrayOf("slack", "teams", "zoom", "webex", "business", "crm", "salesforce", "workspace"),
        6 to arrayOf("docs", "sheets", "slides", "office", "drive", "onedrive", "dropbox", "notes", "keep", "calendar", "todo",
            "pdf", "notion", "evernote", "trello"),
        9 to arrayOf("maps", "uber", "airbnb", "booking", "travel", "flight", "expedia", "waze", "hotel", "airline", "skyscanner"),
        11 to arrayOf("mshop", "shopping", "mercadolibre", "ebay", "aliexpress", "shop", "food", "pedidosya", "ubereats",
            "doordash", "dominos", "kfc", "mcdonalds", "rappi", "walmart", "temu", "shein", "pizza", "restaurant", "delivery"),
        12 to arrayOf("news", "weather", "reader", "books", "kindle", "wikipedia", "cnn", "bbc", "magazine", "pocket", "feedly"),
        13 to arrayOf("fitness", "health", "workout", "yoga", "peloton", "meditation", "headspace", "gym"),
        5 to arrayOf("settings", "filemanager", "file", "explorer", "downloader", "browser", "chrome", "firefox", "puffin", "silk",
            "cleaner", "vpn", "remote", "dashboard", "tcl", "vending", "speedtest", "clock", "calculator", "assistant",
            "launcher", "wifi", "bluetooth", "keyboard", "terminal", "storage", "backup", "store")
    )

    private fun classify(ctx: Context, pkg: String, label: String): Int {
        val key = (pkg + " " + label).lowercase()
        for (r in RULES) for (w in r.second) if (key.contains(w)) return r.first
        try {
            val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
            if (Build.VERSION.SDK_INT >= 26) {
                when (ai.category) {
                    0 -> return 10
                    1, 2 -> return 4
                    3 -> return 3
                    4 -> return 2
                    5 -> return 12
                    6 -> return 9
                    7 -> return 6
                    8 -> return 5
                }
            }
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) return 5
        } catch (e: Throwable) { }
        return 14
    }

    /** Apps installed in the last 30 days, newest first (the ones that came with the TV do not count). */
    private fun recent(ctx: Context, apps: List<AppEntry>): List<AppEntry> = try {
        val pm = ctx.packageManager
        val cut = System.currentTimeMillis() - 30L * 24L * 3600L * 1000L
        apps.mapNotNull { a ->
            try {
                val ai = pm.getApplicationInfo(a.pkg, 0)
                val t = pm.getPackageInfo(a.pkg, 0).firstInstallTime
                if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && t > cut) Pair(a, t) else null
            } catch (e: Throwable) { null }
        }.sortedByDescending { it.second }.take(12).map { it.first }
    } catch (e: Throwable) { emptyList() }

    /** The most used apps of the last 7 days; empty when GlassOS has no usage access. */
    private fun suggestions(ctx: Context, apps: List<AppEntry>): List<AppEntry> = try {
        if (!HomeWatcher.hasAccess(ctx)) {
            emptyList()
        } else {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val stats = usm.queryAndAggregateUsageStats(now - 7L * 24L * 3600L * 1000L, now)
            val byPkg = apps.associateBy { it.pkg }
            stats.values.filter { it.totalTimeInForeground > 60000L && byPkg.containsKey(it.packageName) }
                .sortedByDescending { it.totalTimeInForeground }.take(8).mapNotNull { byPkg[it.packageName] }
        }
    } catch (e: Throwable) { emptyList() }

    fun build(ctx: Context, apps: List<AppEntry>, hidden: Collection<String>): List<LibCat> {
        val visible = apps.filter { it.pkg !in hidden }.sortedBy { it.label.toString().lowercase() }
        val buckets = Array(NAMES.size) { ArrayList<AppEntry>() }
        for (a in visible) buckets[classify(ctx, a.pkg, a.label.toString())].add(a)
        buckets[0].addAll(suggestions(ctx, visible))
        buckets[1].addAll(recent(ctx, visible))
        val cats = ArrayList<LibCat>()
        val hdmiInputs = HdmiManager.getInputs(ctx)
        if (hdmiInputs.isNotEmpty()) {
            val hdmiApps = hdmiInputs.map { entry ->
                val icon = HdmiManager.createIcon(ctx, entry.type, 128)
                AppEntry(
                    pkg = "virtual.hdmi." + entry.id,
                    label = entry.name,
                    art = icon,
                    isBanner = false,
                    color = 0xFF222630.toInt()
                )
            }
            cats.add(LibCat("Inputs", hdmiApps))
        }
        cats.addAll(NAMES.indices.filter { buckets[it].isNotEmpty() }.map { LibCat(NAMES[it], buckets[it]) })
        return cats
    }
}

/** A group of the App Library as a glass card: up to four mini icons in a 2x2 and the group's name. */
class LibCard(ctx: Context, private val cw: Int, private val chh: Int) : View(ctx), StackFocus {
    override var stackY = 0
    var onClick: (() -> Unit)? = null
    var onNav: ((Int) -> Boolean)? = null
    private val radius = ctx.dp(14f)
    private val miniR = ctx.dp(6f)
    private val focus = FocusAnim(this, 1.08f) { invalidate() }
    private val rect = RectF()
    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x1FFFFFFF }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val gp = Paint()
    private val rects = Array(4) { RectF() }
    private val dst = Array(4) { RectF() }
    private val fills = Array(4) { Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG) }
    private val icons = arrayOfNulls<Bitmap>(4)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val moreFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val m = Matrix()
    private var shown = 0
    private var more = 0
    private var moreText = ""
    private var label = ""
    private var labelY = 0f
    private val lt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Fonts.medium
        textSize = chh * 0.085f
        color = 0xF2FFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        setShadowLayer(ctx.dp(3f), 0f, ctx.dp(1f), 0x80000000.toInt())
    }
    private val mt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Fonts.medium
        textSize = chh * 0.09f
        color = 0xE6FFFFFF.toInt()
        textAlign = Paint.Align.CENTER
    }

    init {
        isFocusable = true
        isClickable = true
        outlineProvider = null
        val padX = cw * 0.075f
        val gapM = cw * 0.03f
        val mw = (cw - 2 * padX - gapM) / 2f
        val mh = mw * 9f / 16f
        val top = chh * 0.09f
        for (i in 0 until 4) {
            val l = padX + (i % 2) * (mw + gapM)
            val t = top + (i / 2) * (mh + gapM)
            rects[i].set(l, t, l + mw, t + mh)
            val s = mh * 0.62f
            dst[i].set(rects[i].centerX() - s / 2f, rects[i].centerY() - s / 2f, rects[i].centerX() + s / 2f, rects[i].centerY() + s / 2f)
        }
        labelY = top + 2 * mh + gapM + chh * 0.15f
        rim.shader = LinearGradient(0f, 0f, 0f, chh.toFloat(),
            intArrayOf(alphaOf(Color.WHITE, 0.45f), alphaOf(Color.WHITE, 0.10f)), null, Shader.TileMode.CLAMP)
        setOnClickListener { onClick?.invoke() }
    }

    fun bind(cat: LibCat) {
        val apps = cat.apps
        more = if (apps.size > 4) apps.size - 3 else 0
        shown = if (more > 0) 3 else apps.size.coerceAtMost(4)
        for (i in 0 until 4) {
            icons[i] = null
            fills[i].shader = null
        }
        for (i in 0 until shown) {
            val a = apps[i]
            val art = a.art
            val r = rects[i]
            if (art != null && a.isBanner) {
                val s = BitmapShader(art, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val sc = maxOf(r.width() / art.width.toFloat(), r.height() / art.height.toFloat())
                m.setScale(sc, sc)
                m.postTranslate(r.left + (r.width() - art.width * sc) / 2f, r.top + (r.height() - art.height * sc) / 2f)
                s.setLocalMatrix(m)
                fills[i].shader = s
            } else {
                fills[i].shader = LinearGradient(r.left, r.top, r.left + r.width() * 0.4f, r.bottom,
                    lerpColor(a.color, Color.WHITE, 0.18f), lerpColor(a.color, Color.BLACK, 0.35f), Shader.TileMode.CLAMP)
                icons[i] = art
            }
        }
        moreText = "+" + more
        label = TextUtils.ellipsize(cat.name, lt, cw * 0.9f, TextUtils.TruncateAt.END).toString()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(cw, chh)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pivotX = cw / 2f
        pivotY = chh / 2f
    }

    override fun onFocusChanged(gained: Boolean, direction: Int, previous: Rect?) {
        super.onFocusChanged(gained, direction, previous)
        translationZ = if (gained) 2f else 0f
        focus.set(gained)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN ->
                if (onNav?.invoke(keyCode) == true) return true
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (!event.isCanceled) onClick?.invoke()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onDraw(c: Canvas) {
        val f = focus.amount
        val w = cw.toFloat()
        val h = chh.toFloat()
        rect.set(0f, 0f, w, h)
        val blur = Math.round((dp(8f) + dp(10f) * f) / 4f) * 4f
        GlowCache.draw(c, w, h, radius, blur, Color.BLACK, 0.25f + 0.35f * f, dp(3f) + dp(10f) * f, gp)
        base.alpha = ((0.12f + 0.10f * f) * 255).toInt()
        c.drawRoundRect(rect, radius, radius, base)
        for (i in 0 until shown) {
            c.drawRoundRect(rects[i], miniR, miniR, fills[i])
            val ic = icons[i]
            if (ic != null) c.drawBitmap(ic, null, dst[i], iconPaint)
        }
        if (more > 0) {
            c.drawRoundRect(rects[3], miniR, miniR, moreFill)
            c.drawText(moreText, rects[3].centerX(), rects[3].centerY() - (mt.ascent() + mt.descent()) / 2f, mt)
        }
        c.drawText(label, w / 2f, labelY, lt)

        if (f > 0.01f) {
            ring.strokeWidth = dp(0.75f)
            ring.color = alphaOf(0xFFD8D8DC.toInt(), 0.9f * f)
            val bs = ring.strokeWidth / 2
            c.drawRoundRect(bs, bs, w - bs, h - bs, radius - bs, radius - bs, ring)
        }
        rim.strokeWidth = dp(0.8f)
        rim.alpha = ((0.385f + 0.615f * f) * 255).toInt()
        val hs = rim.strokeWidth / 2
        c.drawRoundRect(hs, hs, w - hs, h - hs, radius - hs, radius - hs, rim)
    }
}

/** Centered glass folder modal for one App Library category. */
class LibraryPanel(private val ctx: Context, private val host: HomeScreen,
                   private val tileW: Int, private val tileH: Int, private val margin: Int, private val gap: Int) : FrameLayout(ctx) {
    private val sw = Backdrop.screenW.coerceAtLeast(1)
    private val sh = Backdrop.screenH.coerceAtLeast(1)
    private val panelW = minOf((sw * 0.92f).toInt(), sw - ctx.dpi(48f)).coerceAtLeast(ctx.dpi(320f))
    private val panelH = minOf((sh * 0.84f).toInt(), sh - ctx.dpi(48f)).coerceAtLeast(ctx.dpi(300f))
    private val modalTileW = (tileW * 0.88f).toInt().coerceAtLeast(ctx.dpi(96f))
    private val modalTileH = (tileH * 0.88f).toInt().coerceAtLeast(ctx.dpi(54f))
    private val modalLabelH = ctx.dpi(28f)
    private val modalGap = (gap * 0.65f).toInt().coerceAtLeast(ctx.dpi(12f))

    private var origin: View? = null
    private var closing = false
    var isOpen = false
        private set

    private val scrim = View(ctx).apply {
        setBackgroundColor(0xB8000000.toInt())
        isClickable = true
        isFocusable = false
        setOnClickListener { close() }
    }

    private val panel = GlassBox(ctx, ctx.dp(34f)).apply {
        glass.tint = 0.075f
        glass.dark = 0.58f
        glass.sheen = 0.13f
        glass.highlight = 0.46f
        glass.border = 0.22f
        glass.grain = 0.30f
        shadowAlpha = 0.72f
        clipChildren = false
        clipToPadding = false
        isFocusable = false
        descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        // Absorb taps on the empty glass area; only taps on the scrim dismiss the folder.
        setOnClickListener { }
    }

    private val inner = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        clipChildren = false
        clipToPadding = false
        descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        setPadding(ctx.dpi(34f), ctx.dpi(30f), ctx.dpi(34f), ctx.dpi(24f))
    }
    private val header = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val titleView = TextView(ctx).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        typeface = Fonts.medium
        setTextColor(0xF7FFFFFF.toInt())
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val countView = TextView(ctx).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        typeface = Fonts.regular
        setTextColor(0xBFFFFFFF.toInt())
    }
    private val scroll = ScrollView(ctx).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        clipChildren = false
        clipToPadding = false
        descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        setPadding(0, ctx.dpi(8f), 0, ctx.dpi(14f))
    }
    private val list = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        clipChildren = false
        clipToPadding = false
    }

    init {
        visibility = View.GONE
        clipChildren = false
        clipToPadding = false
        isFocusable = false
        addView(scrim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(panel, LayoutParams(panelW, panelH, Gravity.CENTER))

        header.addView(titleView, LinearLayout.LayoutParams(-1, -2))
        header.addView(countView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dpi(5f) })
        inner.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ctx.dpi(18f) })
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        inner.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(inner, FrameLayout.LayoutParams(-1, -1))
    }

    init { visibility = View.GONE }

    fun open(cat: LibCat, from: View?) {
        if (isOpen) return
        closing = false
        isOpen = true
        origin = from
        titleView.text = cat.name
        countView.text = cat.apps.size.toString() + if (cat.apps.size == 1) " app" else " apps"
        list.removeAllViews()

        val tileRows = ArrayList<List<TileView>>()
        for (chunk in cat.apps.chunked(HomeScreen.COLS)) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_HORIZONTAL
                clipChildren = false
                clipToPadding = false
            }
            val rowTiles = ArrayList<TileView>()
            chunk.forEachIndexed { i, a ->
                val tile = TileView(ctx, modalTileW, modalTileH, modalLabelH).apply {
                    app = a
                    id = View.generateViewId()
                    tag = -1
                    onClick = {
                        if (a.pkg.startsWith("virtual.hdmi.")) {
                            val inputId = a.pkg.removePrefix("virtual.hdmi.")
                            val target = HdmiManager.getInputs(ctx).firstOrNull { it.id == inputId }
                            if (target != null) {
                                HdmiManager.switchInput(ctx, target)
                                close(instant = true)
                            }
                        } else if (host.launch(a.pkg, this)) {
                            close(instant = true)
                        }
                    }
                    onLongPress = {
                        host.showAppContextMenu(a, this)
                    }
                }

                val totalCols = HomeScreen.COLS.toFloat()
                val colOffset = (i - (totalCols / 2f))
                tile.alpha = 0f
                tile.translationY = -ctx.dpi(48f).toFloat()
                tile.translationX = colOffset * -ctx.dpi(14f).toFloat()
                tile.rotation = colOffset * 3.5f
                tile.scaleX = 0.82f
                tile.scaleY = 0.82f

                val cardDelay = (tileRows.size * HomeScreen.COLS + i) * 35L
                tile.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .translationX(0f)
                    .rotation(0f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setStartDelay(cardDelay)
                    .setDuration(290L)
                    .setInterpolator(OvershootInterpolator(1.18f))
                    .start()

                row.addView(tile, LinearLayout.LayoutParams(-2, -2).apply {
                    if (i > 0) leftMargin = modalGap
                })
                rowTiles.add(tile)
            }
            tileRows.add(rowTiles)
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ctx.dpi(18f) })
        }

        // Explicit D-pad links keep focus inside the folder, including at the edges and on a short last row.
        for (r in tileRows.indices) {
            val row = tileRows[r]
            for (c in row.indices) {
                val tile = row[c]
                tile.nextFocusLeftId = row.getOrNull(c - 1)?.id ?: tile.id
                tile.nextFocusRightId = row.getOrNull(c + 1)?.id ?: tile.id
                val up = tileRows.getOrNull(r - 1)
                val down = tileRows.getOrNull(r + 1)
                tile.nextFocusUpId = up?.getOrNull(c.coerceAtMost((up.size - 1).coerceAtLeast(0)))?.id ?: tile.id
                tile.nextFocusDownId = down?.getOrNull(c.coerceAtMost((down.size - 1).coerceAtLeast(0)))?.id ?: tile.id
            }
        }

        if (host.prefs.sound) HomeShare.sound(ctx)?.cardDeal()
        host.onLibraryOpen()
        scroll.scrollTo(0, 0)
        scrim.animate().cancel()
        panel.animate().cancel()
        visibility = View.VISIBLE
        scrim.alpha = 0f
        panel.alpha = 0f
        panel.scaleX = 0.965f
        panel.scaleY = 0.965f
        scrim.animate().alpha(1f).setDuration(180).start()
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator(1.8f))
            .withEndAction { invalidateDeep(panel) }
            .start()
        post {
            tileRows.firstOrNull()?.firstOrNull()?.requestFocus()
            invalidateDeep(panel)
        }
    }

    fun close(instant: Boolean = false) {
        if (!isOpen || closing) return
        val back = origin
        scrim.animate().cancel()
        panel.animate().cancel()
        if (instant) {
            visibility = View.GONE
            list.removeAllViews()
            scrim.alpha = 1f
            panel.alpha = 1f
            panel.scaleX = 1f
            panel.scaleY = 1f
            origin = null
            isOpen = false
            closing = false
            host.onLibraryClosed(back)
            return
        }
        if (host.prefs.sound) HomeShare.sound(ctx)?.folderClose()
        closing = true
        scrim.animate().alpha(0f).setDuration(160).start()
        panel.animate().alpha(0f).scaleX(0.965f).scaleY(0.965f).setDuration(160)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                visibility = View.GONE
                list.removeAllViews()
                scrim.alpha = 1f
                panel.alpha = 1f
                panel.scaleX = 1f
                panel.scaleY = 1f
                origin = null
                closing = false
                // Restore home focus only after the modal is gone, so the background never steals D-pad input.
                host.onLibraryClosed(back)
            }
            .start()
    }
}

private class MediaData(val tracks: List<SpotTrack>, val art: List<Bitmap?>, val playing: Boolean)

/**
 * The block under the top row of apps: a dark glass band with the Spotify cards, a second one with the App Library
 * cards, then an "Apps" title before the drawer. Each part shows only when it has something.
 */
class MediaRow(private val ctx: Context, private val host: HomeScreen,
               private val tileW: Int, private val tileH: Int, private val margin: Int, private val gap: Int) {
    private val sw = Backdrop.screenW
    private val sh = Backdrop.screenH
    private val cardGap = sw * 40 / 1920
    private val cardW = (sw - 2 * margin - (COLS - 1) * cardGap) / COLS
    private val cardH = cardW * 64 / 100
    private val padV = sh * 24 / 1080
    private val titleTop = sh * 14 / 1080
    private val titleH = sh * 34 / 1080
    private val titleGap = sh * 34 / 1080
    private val bandH = titleTop + titleH + titleGap + cardH + padV
    private val libCols = 5
    private val libGap = sw * 36 / 1920
    private val catW = (sw - 2 * margin - (libCols - 1) * libGap) / libCols
    private val catH = sh * 250 / 1080
    private val catRowGap = sh * 28 / 1080
    private val between = sh * 26 / 1080
    private val gapAfter = sh * 34 / 1080
    private val appsGap = sh * 14 / 1080
    private val bandLeft = sw * 12 / 1920
    private val ui = Handler(Looper.getMainLooper())
    private var current: List<SpotTrack> = emptyList()
    private var cats: List<LibCat> = emptyList()
    private var catSig = ""
    private var total = 0
    /** Extra height this block adds to the drawer; 0 while it has nothing to show. */
    var shift = 0
        private set

    val container = FrameLayout(ctx).apply { clipChildren = false; visibility = View.GONE }
    private val band = glassBand()
    private val libBand = glassBand()
    private val titleView = label("Continue listening")
    private val libTitle = label("App Library")
    private val appsView = label("Apps")
    private val cards = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false; clipToPadding = false }
    private val libGrid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
    private val libRows = ArrayList<ArrayList<LibCard>>()
    val library = LibraryPanel(ctx, host, tileW, tileH, margin, gap)
    val isLibraryOpen: Boolean get() = library.isOpen

    private fun glassBand() = GlassBox(ctx, sw * 48f / 1920f).apply {
        glass.tint = 0.05f
        glass.dark = 0.46f
        glass.sheen = 0.04f
        glass.highlight = 0.40f
        glass.border = 0.10f
        glass.cacheStatic = true
        shadowAlpha = 0.25f
    }

    private fun label(s: String) = TextView(ctx).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_PX, sh * 26f / 1080f)
        typeface = Fonts.medium
        setTextColor(0xF2FFFFFF.toInt())
        setShadowLayer(ctx.dp(8f), 0f, ctx.dp(1f), 0x80000000.toInt())
        alpha = 0f
    }

    private fun params(w: Int, h: Int, left: Int, top: Int) = FrameLayout.LayoutParams(w, h).apply { leftMargin = left; topMargin = top }

    init {
        cards.setPadding(margin, 0, 0, 0)
        container.addView(band, params(sw - 2 * bandLeft, bandH, bandLeft, 0))
        container.addView(titleView, params(-2, -2, margin, 0))
        container.addView(cards, params(-1, cardH, 0, 0))
        container.addView(libBand, params(sw - 2 * bandLeft, bandH, bandLeft, 0))
        container.addView(libTitle, params(-2, -2, margin, 0))
        container.addView(libGrid, params(-1, catH, 0, 0))
        container.addView(appsView, params(-2, -2, margin, 0))
    }

    /** Puts the block in the drawer, where the first row of apps used to start. */
    fun attach(content: FrameLayout, base: Int) {
        val lp = FrameLayout.LayoutParams(-1, total).apply { topMargin = base }
        if (container.parent === content) container.layoutParams = lp else content.addView(container, lp)
    }

    fun attachOverlay(root: FrameLayout) {
        root.addView(library, FrameLayout.LayoutParams(-1, -1))
    }

    fun closeLibrary() { library.close() }

    fun setTitleShown(show: Boolean) {
        val a = if (show) 1f else 0f
        titleView.animate().alpha(a).setDuration(260).start()
        libTitle.animate().alpha(a).setDuration(260).start()
        appsView.animate().alpha(a).setDuration(260).start()
    }

    /** The bands sample the art behind them, so they redraw with the Top Shelf. */
    fun invalidateGlass() {
        if (shift > 0) {
            band.invalidate()
            libBand.invalidate()
        }
    }

    /** From the top row of apps: the first thing of the block, in the same column. */
    fun focusAt(col: Int): Boolean = focusFirst(col)

    fun focusFirst(col: Int): Boolean {
        if (shift == 0) return false
        if (cards.childCount > 0) {
            cards.getChildAt(col.coerceIn(0, cards.childCount - 1)).requestFocus()
            return true
        }
        val row = libRows.firstOrNull() ?: return false
        row[col.coerceIn(0, row.size - 1)].requestFocus()
        return true
    }

    /** From the drawer going up: the last thing of the block, in the same column. */
    fun focusLast(col: Int): Boolean {
        if (shift == 0) return false
        val row = libRows.lastOrNull()
        if (row != null) {
            row[col.coerceIn(0, row.size - 1)].requestFocus()
            return true
        }
        if (cards.childCount > 0) {
            cards.getChildAt(col.coerceIn(0, cards.childCount - 1)).requestFocus()
            return true
        }
        return false
    }

    private fun nav(card: MediaCard, code: Int): Boolean {
        val i = cards.indexOfChild(card)
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> if (i > 0) cards.getChildAt(i - 1).requestFocus()
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (i < cards.childCount - 1) cards.getChildAt(i + 1).requestFocus()
            KeyEvent.KEYCODE_DPAD_UP -> host.focusDock()
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (libRows.isNotEmpty()) {
                    val row = libRows[0]
                    row[i.coerceAtMost(row.size - 1)].requestFocus()
                } else {
                    host.focusDrawerCol(i)
                }
            }
            else -> return false
        }
        return true
    }

    private fun libNav(card: LibCard, code: Int): Boolean {
        var r = -1
        var c = -1
        for (i in libRows.indices) {
            val j = libRows[i].indexOf(card)
            if (j >= 0) { r = i; c = j }
        }
        if (r < 0) return false
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> if (c > 0) libRows[r][c - 1].requestFocus()
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (c < libRows[r].size - 1) libRows[r][c + 1].requestFocus()
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (r > 0) {
                    val row = libRows[r - 1]
                    row[c.coerceAtMost(row.size - 1)].requestFocus()
                } else if (cards.childCount > 0) {
                    cards.getChildAt(c.coerceAtMost(cards.childCount - 1)).requestFocus()
                } else {
                    host.focusDock()
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (r < libRows.size - 1) {
                    val row = libRows[r + 1]
                    row[c.coerceAtMost(row.size - 1)].requestFocus()
                } else {
                    host.focusDrawerCol(c)
                }
            }
            else -> return false
        }
        return true
    }

    /** Lays the parts out one under the other, hides the empty ones and tells the home when the height changes. */
    private fun relayout() {
        val hasMedia = cards.childCount > 0
        val rowsN = libRows.size
        val hasLib = rowsN > 0
        var y = 0
        var endY = 0
        val vm = if (hasMedia) View.VISIBLE else View.GONE
        band.visibility = vm
        titleView.visibility = vm
        cards.visibility = vm
        if (hasMedia) {
            band.layoutParams = params(sw - 2 * bandLeft, bandH, bandLeft, y)
            titleView.layoutParams = params(-2, -2, margin, y + titleTop)
            val top = y + titleTop + titleH + titleGap
            cards.layoutParams = params(-1, cardH, 0, top)
            for (i in 0 until cards.childCount) (cards.getChildAt(i) as MediaCard).stackY = top
            endY = y + bandH
            y = endY + between
        }
        val vl = if (hasLib) View.VISIBLE else View.GONE
        libBand.visibility = vl
        libTitle.visibility = vl
        libGrid.visibility = vl
        if (hasLib) {
            val gridH = rowsN * catH + (rowsN - 1) * catRowGap
            val libH = titleTop + titleH + titleGap + gridH + padV
            libBand.layoutParams = params(sw - 2 * bandLeft, libH, bandLeft, y)
            libTitle.layoutParams = params(-2, -2, margin, y + titleTop)
            val top = y + titleTop + titleH + titleGap
            libGrid.layoutParams = params(-1, gridH, 0, top)
            for (r in 0 until rowsN) for (cd in libRows[r]) cd.stackY = top + r * (catH + catRowGap)
            endY = y + libH
        }
        val any = hasMedia || hasLib
        val appsTop = endY + gapAfter
        appsView.layoutParams = params(-2, -2, margin, appsTop)
        total = if (any) appsTop + titleH + appsGap else 0
        appsView.visibility = if (any) View.VISIBLE else View.GONE
        container.visibility = if (any) View.VISIBLE else View.GONE
        val clp = container.layoutParams as? FrameLayout.LayoutParams
        if (clp != null && clp.height != total) {
            clp.height = total
            container.layoutParams = clp
        }
        if (total != shift) {
            shift = total
            host.onMediaChanged()
        }
    }

    // ---------- App Library ----------

    /** Called when the app list loads or changes: the groups are worked out off the main thread. */
    fun setApps(list: List<AppEntry>) {
        val hidden = host.prefs.hidden
        Thread {
            val built = try { AppLibrary.build(ctx.applicationContext, list, hidden) } catch (e: Throwable) { emptyList() }
            ui.post { applyCats(built) }
        }.apply { priority = Thread.MIN_PRIORITY; isDaemon = true }.start()
    }

    private fun applyCats(built: List<LibCat>) {
        val sig = built.joinToString("|") { c -> c.name + ":" + c.apps.joinToString(",") { it.pkg } }
        if (sig == catSig) return
        catSig = sig
        cats = built
        libGrid.removeAllViews()
        libRows.clear()
        built.chunked(libCols).forEachIndexed { r, chunk ->
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                clipChildren = false
                clipToPadding = false
                setPadding(margin, 0, 0, 0)
            }
            val rowCards = ArrayList<LibCard>()
            chunk.forEachIndexed { i, cat ->
                val cd = LibCard(ctx, catW, catH)
                cd.bind(cat)
                cd.onNav = { code -> libNav(cd, code) }
                cd.onClick = { library.open(cat, cd) }
                row.addView(cd, LinearLayout.LayoutParams(-2, -2).apply { if (i > 0) leftMargin = libGap })
                rowCards.add(cd)
            }
            libRows.add(rowCards)
            libGrid.addView(row, LinearLayout.LayoutParams(-1, catH).apply { if (r > 0) topMargin = catRowGap })
        }
        relayout()
    }

    // ---------- Spotify ----------

    /** Shows what is cached at once, then asks Spotify again when the data is more than 2 minutes old. */
    fun refresh() {
        cached?.let { show(it) }
        val now = SystemClock.elapsedRealtime()
        if (loading || (cachedAt != 0L && now - cachedAt < 2 * 60_000L)) return
        loading = true
        Thread {
            val d = try { load() } catch (e: Throwable) { null }
            loading = false
            if (d != null) {
                cached = d
                cachedAt = SystemClock.elapsedRealtime()
                ui.post { show(d) }
            }
        }.apply { priority = Thread.MIN_PRIORITY; isDaemon = true }.start()
    }

    private fun load(): MediaData? {
        val app = ctx.applicationContext
        val now = SpotifyClient.nowPlaying(app)
        val recent = SpotifyClient.recent(app, 20)
        if (recent == null && now == null) return null
        val list = ArrayList<SpotTrack>()
        if (now != null) list.add(now.first)
        recent?.forEach { t -> if (list.none { it.id == t.id }) list.add(t) }
        val top = list.take(COLS)
        val art = arrayOfNulls<Bitmap>(top.size)
        val workers = top.mapIndexed { i, t ->
            Thread { art[i] = t.artUrl?.let { bitmap(it) } }.also { it.isDaemon = true; it.start() }
        }
        workers.forEach { try { it.join(10000) } catch (e: InterruptedException) { } }
        return MediaData(top, art.toList(), now?.second == true)
    }

    private fun bitmap(url: String): Bitmap? {
        bitmaps.get(url)?.let { return it }
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val b = try { c.inputStream.use { BitmapFactory.decodeStream(it) } } finally { c.disconnect() }
            if (b != null) bitmaps.put(url, b)
            b
        } catch (e: Throwable) { null }
    }

    private fun show(d: MediaData) {
        val n = d.tracks.size.coerceAtMost(COLS)
        while (cards.childCount > n) cards.removeViewAt(cards.childCount - 1)
        while (cards.childCount < n) {
            val c = MediaCard(ctx, cardW, cardH)
            c.onNav = { code -> nav(c, code) }
            c.onClick = {
                val t = current.getOrNull(cards.indexOfChild(c))
                if (t != null) host.openUri(t.uri, SPOTIFY_PKG, c)
            }
            val lp = LinearLayout.LayoutParams(-2, -2)
            if (cards.childCount > 0) lp.leftMargin = cardGap
            cards.addView(c, lp)
        }
        current = d.tracks.take(n)
        for (i in 0 until n) {
            (cards.getChildAt(i) as MediaCard).bind(d.tracks[i], d.art.getOrNull(i), if (i == 0 && d.playing) "Now playing" else "Spotify")
        }
        relayout()
    }

    companion object {
        private const val COLS = 4
        private const val SPOTIFY_PKG = "com.spotify.tv.android"
        @Volatile private var cached: MediaData? = null
        @Volatile private var cachedAt = 0L
        @Volatile private var loading = false
        /** Covers, up to 8 MB; the oldest ones leave first. */
        private val bitmaps = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }
    }
}