package io.github.abhishekkaisar.glassos

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Build

enum class ConsoleType { SWITCH, PLAYSTATION, XBOX, HDMI_GENERIC }

data class TvInputEntry(
    val id: String,
    val name: String,
    val sub: String,
    val type: ConsoleType,
    val isConnected: Boolean
)

object HdmiManager {
    fun getInputs(ctx: Context): List<TvInputEntry> {
        val list = ArrayList<TvInputEntry>()
        try {
            val tim = ctx.getSystemService(Context.TV_INPUT_SERVICE) as? TvInputManager
            val tvInputs = tim?.tvInputList ?: emptyList()

            for (info in tvInputs) {
                if (info.type == TvInputInfo.TYPE_HDMI || info.id.contains("hdmi", ignoreCase = true)) {
                    val rawLabel = (info.loadCustomLabel(ctx) ?: info.loadLabel(ctx) ?: "").toString()
                    val id = info.id
                    val detected = detectType(rawLabel, id)
                    val friendlyName = when {
                        rawLabel.isNotBlank() -> rawLabel
                        id.contains("HW1") || id.contains("HDMI1") -> "HDMI 1"
                        id.contains("HW2") || id.contains("HDMI2") -> "HDMI 2 (eARC)"
                        id.contains("HW3") || id.contains("HDMI3") -> "HDMI 3"
                        else -> "HDMI"
                    }
                    val sub = when (detected) {
                        ConsoleType.SWITCH -> "Nintendo Switch"
                        ConsoleType.PLAYSTATION -> "PlayStation"
                        ConsoleType.XBOX -> "Xbox Console"
                        ConsoleType.HDMI_GENERIC -> "HDMI port"
                    }
                    list.add(TvInputEntry(id, friendlyName, sub, detected, true))
                }
            }
        } catch (e: Throwable) { }

        // Si el televisor no expone la lista por permisos o modo demo, proveer los 3 puertos estandar
        if (list.isEmpty()) {
            list.add(TvInputEntry("HDMI1", "HDMI 1", "Nintendo Switch", ConsoleType.SWITCH, true))
            list.add(TvInputEntry("HDMI2", "HDMI 2 (eARC)", "PlayStation 5", ConsoleType.PLAYSTATION, true))
            list.add(TvInputEntry("HDMI3", "HDMI 3", "Console / PC", ConsoleType.XBOX, true))
        }
        return list
    }

    private fun detectType(label: String, id: String): ConsoleType {
        val s = (label + " " + id).lowercase()
        return when {
            s.contains("switch") || s.contains("nintendo") -> ConsoleType.SWITCH
            s.contains("playstation") || s.contains("ps5") || s.contains("ps4") || s.contains("sony") -> ConsoleType.PLAYSTATION
            s.contains("xbox") || s.contains("microsoft") -> ConsoleType.XBOX
            else -> ConsoleType.HDMI_GENERIC
        }
    }

    fun switchInput(ctx: Context, input: TvInputEntry) {
        try {
            val uri = TvContract.buildChannelUriForPassthroughInput(input.id)
            val i = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
        } catch (e: Throwable) {
            // Intento alternativo para TCL / Android TV generico
            try {
                val altIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
                    setPackage("com.tcl.tvinput")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(altIntent)
            } catch (ex: Throwable) { }
        }
    }

    fun createIcon(ctx: Context, type: ConsoleType, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = RectF(0f, 0f, size.toFloat(), size.toFloat())
        val rad = size * 0.22f

        when (type) {
            ConsoleType.SWITCH -> {
                // Fondo partido Rojo Neon / Azul Neon
                p.color = 0xFFE60012.toInt()
                c.drawRoundRect(r, rad, rad, p)
                p.color = 0xFF00BDFF.toInt()
                val half = RectF(size * 0.5f, 0f, size.toFloat(), size.toFloat())
                c.save()
                c.clipRect(half)
                c.drawRoundRect(r, rad, rad, p)
                c.restore()

                // Silueta blanca de Joy-Cons
                p.color = Color.WHITE
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.05f
                val jw = size * 0.18f
                val jh = size * 0.52f
                val jy = size * 0.24f
                c.drawRoundRect(RectF(size * 0.24f, jy, size * 0.24f + jw, jy + jh), jw * 0.4f, jw * 0.4f, p)
                c.drawRoundRect(RectF(size * 0.58f, jy, size * 0.58f + jw, jy + jh), jw * 0.4f, jw * 0.4f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(size * 0.33f, jy + jh * 0.3f, size * 0.04f, p)
                c.drawCircle(size * 0.67f, jy + jh * 0.7f, size * 0.04f, p)
            }
            ConsoleType.PLAYSTATION -> {
                // Azul PlayStation profundo
                p.color = 0xFF003791.toInt()
                c.drawRoundRect(r, rad, rad, p)

                // Simbolos geometricos iluminados
                p.color = Color.WHITE
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.055f
                val cx = size * 0.5f
                val cy = size * 0.5f
                c.drawCircle(cx, cy, size * 0.22f, p)
            }
            ConsoleType.XBOX -> {
                // Verde Xbox
                p.color = 0xFF107C10.toInt()
                c.drawRoundRect(r, rad, rad, p)

                // Esfera con X estilizada
                p.color = Color.WHITE
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.06f
                val cx = size * 0.5f
                val cy = size * 0.5f
                c.drawCircle(cx, cy, size * 0.25f, p)
                c.drawLine(cx - size * 0.14f, cy - size * 0.14f, cx + size * 0.14f, cy + size * 0.14f, p)
                c.drawLine(cx + size * 0.14f, cy - size * 0.14f, cx - size * 0.14f, cy + size * 0.14f, p)
            }
            ConsoleType.HDMI_GENERIC -> {
                // Negro obsidiana con conector HDMI dorado
                p.color = 0xFF222630.toInt()
                c.drawRoundRect(r, rad, rad, p)
                p.color = 0xFFFFD700.toInt()
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.06f
                val hw = size * 0.48f
                val hh = size * 0.28f
                val hx = (size - hw) / 2f
                val hy = (size - hh) / 2f
                c.drawRoundRect(RectF(hx, hy, hx + hw, hy + hh), size * 0.08f, size * 0.08f, p)
            }
        }
        return bmp
    }
}