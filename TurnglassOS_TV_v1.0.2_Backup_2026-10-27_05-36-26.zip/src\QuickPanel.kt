package io.github.abhishekkaisar.glassos

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.media.AudioManager
import android.text.TextPaint
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import android.provider.Settings as AndroidSettings

/** One glass button of the quick panel. */
class QuickItem(ctx: Context, val kind: Int, private val bw: Int, private val bh: Int) : View(ctx) {
    companion object {
        const val THEME = 0
        const val PHOTOS = 1
        const val SLIDER = 2
        const val CLOCK = 3
        const val PICTURE = 4
        const val SLEEP = 5
        const val SETTINGS = 6
    }

    var onClick: (() -> Unit)? = null
    var onChange: ((Int) -> Unit)? = null
    var light = false
        set(v) { if (field != v) { field = v; invalidate() } }
    var subtitle = ""
        set(v) { if (field != v) { field = v; invalidate() } }
    var percent = 50
        set(v) { val n = v.coerceIn(0, 100); if (field != n) { field = n; invalidate() } }

    private val label = when (kind) {
        THEME -> "Theme"
        PHOTOS -> "Photos"
        CLOCK -> "Clock"
        PICTURE -> "Inputs"
        SLEEP -> "Sleep"
        SETTINGS -> "Settings"
        else -> "Volume"
    }
    private val glass = GlassPainter().apply { stroke = ctx.dp(0.6f) }
    private val focus = FocusAnim(this, 1.06f) { invalidate() }
    private val rect = RectF()
    private val tmp = RectF()
    private val gp = Paint()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ico = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val clip = Path()
    private val moon = Path()
    private val cut = Path()
    private val mtn = Path()
    private val spk = Path()
    private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; textSize = px(23f) }
    private val sub = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.regular; textSize = px(18f) }

    init {
        isFocusable = true
        isClickable = true
        outlineProvider = null
        setOnClickListener { onClick?.invoke() }
    }

    private fun px(v: Float): Float = Backdrop.screenH * v / 1080f

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(bw, bh)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pivotX = w / 2f
        pivotY = h / 2f
    }

    override fun onFocusChanged(gained: Boolean, direction: Int, previous: Rect?) {
        super.onFocusChanged(gained, direction, previous)
        translationZ = if (gained) 2f else 0f
        focus.set(gained)
    }

    private fun step(d: Int) {
        percent = (percent + d).coerceIn(0, 100)
        onChange?.invoke(percent)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (kind == SLIDER && keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { step(-5); return true }
        if (kind == SLIDER && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { step(5); return true }
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (!event.isCanceled) onClick?.invoke()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun speakerIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        val prevStyle = ico.style
        ico.style = Paint.Style.FILL
        spk.reset()
        val bw = r * 0.28f
        val bh = r * 0.40f
        val coneW = r * 0.38f
        val coneH = r * 0.85f
        val startX = cx - r * 0.60f

        spk.moveTo(startX, cy - bh / 2f)
        spk.lineTo(startX + bw, cy - bh / 2f)
        spk.lineTo(startX + bw + coneW, cy - coneH / 2f)
        spk.lineTo(startX + bw + coneW, cy + coneH / 2f)
        spk.lineTo(startX + bw, cy + bh / 2f)
        spk.lineTo(startX, cy + bh / 2f)
        spk.close()
        c.drawPath(spk, ico)

        ico.style = Paint.Style.STROKE
        val waveBaseX = startX + bw + coneW + r * 0.12f
        tmp.set(waveBaseX - r * 0.35f, cy - r * 0.38f, waveBaseX + r * 0.35f, cy + r * 0.38f)
        c.drawArc(tmp, -45f, 90f, false, ico)
        tmp.set(waveBaseX - r * 0.65f, cy - r * 0.68f, waveBaseX + r * 0.65f, cy + r * 0.68f)
        c.drawArc(tmp, -45f, 90f, false, ico)
        ico.style = prevStyle
    }

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        ico.style = Paint.Style.STROKE
        c.drawCircle(cx, cy, r * 0.42f, ico)
        for (i in 0 until 8) {
            val a = i * PI.toFloat() / 4f
            c.drawLine(cx + cos(a) * r * 0.66f, cy + sin(a) * r * 0.66f, cx + cos(a) * r * 0.96f, cy + sin(a) * r * 0.96f, ico)
        }
    }

    private fun moonIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        moon.reset()
        cut.reset()
        moon.addCircle(cx, cy, r * 0.82f, Path.Direction.CW)
        cut.addCircle(cx + r * 0.42f, cy - r * 0.32f, r * 0.68f, Path.Direction.CW)
        moon.op(cut, Path.Op.DIFFERENCE)
        ico.style = Paint.Style.FILL
        c.drawPath(moon, ico)
    }

    private fun photosIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        ico.style = Paint.Style.STROKE
        val l = cx - r * 0.92f
        val t = cy - r * 0.74f
        val rr = cx + r * 0.92f
        val b = cy + r * 0.74f
        c.drawRoundRect(l, t, rr, b, r * 0.22f, r * 0.22f, ico)
        c.drawCircle(cx - r * 0.38f, cy - r * 0.22f, r * 0.15f, ico)
        mtn.reset()
        mtn.moveTo(l + r * 0.15f, b - r * 0.15f)
        mtn.lineTo(cx - r * 0.05f, cy)
        mtn.lineTo(cx + r * 0.3f, cy + r * 0.35f)
        mtn.lineTo(cx + r * 0.5f, cy + r * 0.15f)
        mtn.lineTo(rr - r * 0.15f, b - r * 0.15f)
        c.drawPath(mtn, ico)
    }

    private fun clockIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        ico.style = Paint.Style.STROKE
        c.drawCircle(cx, cy, r * 0.85f, ico)
        c.drawLine(cx, cy, cx, cy - r * 0.5f, ico)
        c.drawLine(cx, cy, cx + r * 0.38f, cy + r * 0.22f, ico)
    }

    private fun monitorIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        ico.style = Paint.Style.STROKE
        c.drawRoundRect(cx - r * 0.92f, cy - r * 0.72f, cx + r * 0.92f, cy + r * 0.34f, r * 0.16f, r * 0.16f, ico)
        c.drawLine(cx, cy + r * 0.34f, cx, cy + r * 0.7f, ico)
        c.drawLine(cx - r * 0.42f, cy + r * 0.72f, cx + r * 0.42f, cy + r * 0.72f, ico)
    }

    private fun powerIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        ico.style = Paint.Style.STROKE
        tmp.set(cx - r * 0.72f, cy - r * 0.62f, cx + r * 0.72f, cy + r * 0.82f)
        c.drawArc(tmp, -60f, 300f, false, ico)
        c.drawLine(cx, cy - r * 0.9f, cx, cy - r * 0.1f, ico)
    }

    private fun gearIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        ico.style = Paint.Style.STROKE
        c.drawCircle(cx, cy, r * 0.5f, ico)
        c.drawCircle(cx, cy, r * 0.18f, ico)
        val w0 = ico.strokeWidth
        ico.strokeWidth = w0 * 1.8f
        for (i in 0 until 8) {
            val a = i * PI.toFloat() / 4f
            c.drawLine(cx + cos(a) * r * 0.68f, cy + sin(a) * r * 0.68f, cx + cos(a) * r * 0.9f, cy + sin(a) * r * 0.9f, ico)
        }
        ico.strokeWidth = w0
    }

    override fun onDraw(c: Canvas) {
        val f = focus.amount
        val w = width.toFloat()
        val hh = height.toFloat()
        val r = hh / 2f
        rect.set(0f, 0f, w, hh)
        GlowCache.draw(c, w, hh, r, dp(8f), Color.BLACK, 0.22f + 0.2f * f, dp(3f), gp)
        GlowCache.draw(c, w, hh, r, dp(10f), Color.WHITE, 0.28f * f, 0f, gp)
        glass.tintColor = Color.WHITE
        if (light) {
            glass.tint = 0.34f + 0.12f * f
            glass.dark = 0f
            glass.sheen = 0.12f
            glass.highlight = 0.75f
            glass.border = 0.22f
        } else {
            glass.tint = 0.06f + 0.10f * f
            glass.dark = 0.30f
            glass.sheen = 0.07f
            glass.highlight = 0.50f
            glass.border = 0.14f
        }
        glass.draw(c, this, rect, r)

        if (kind == SLIDER) {
            c.save()
            clip.reset()
            clip.addRoundRect(rect, r, r, Path.Direction.CW)
            c.clipPath(clip)
            fill.color = if (light) alphaOf(Color.WHITE, 0.55f) else alphaOf(Color.WHITE, 0.20f)
            c.drawRect(0f, 0f, w * percent / 100f, hh, fill)
            c.restore()
        }

        if (f > 0.01f) {
            ring.strokeWidth = dp(1.2f)
            ring.color = alphaOf(if (light) 0xFF101218.toInt() else Color.WHITE, 0.85f * f)
            val hs = ring.strokeWidth / 2
            c.drawRoundRect(hs, hs, w - hs, hh - hs, r - hs, r - hs, ring)
        }

        val tc = if (light) 0xFF101218.toInt() else 0xF2FFFFFF.toInt()
        title.color = tc
        sub.color = if (light) 0xB3101218.toInt() else 0xB3FFFFFF.toInt()
        ico.color = tc
        ico.strokeWidth = dp(1.7f)
        val pad = px(26f)
        val isz = px(30f)
        val icx = pad + isz / 2f
        val cy = hh / 2f
        when (kind) {
            THEME -> if (light) sun(c, icx, cy, isz / 2f) else moonIcon(c, icx, cy, isz / 2f)
            PHOTOS -> photosIcon(c, icx, cy, isz / 2f)
            CLOCK -> clockIcon(c, icx, cy, isz / 2f)
            PICTURE -> monitorIcon(c, icx, cy, isz / 2f)
            SLEEP -> powerIcon(c, icx, cy, isz / 2f)
            SETTINGS -> gearIcon(c, icx, cy, isz / 2f)
            else -> speakerIcon(c, icx, cy, isz / 2f)
        }
        val tx = pad + isz + px(16f)
        if (kind == SLIDER) {
            c.drawText(label, tx, cy - (title.ascent() + title.descent()) / 2f, title)
            sub.textAlign = Paint.Align.RIGHT
            c.drawText(percent.toString(), w - pad, cy - (sub.ascent() + sub.descent()) / 2f, sub)
            sub.textAlign = Paint.Align.LEFT
        } else {
            c.drawText(label, tx, cy - px(2f), title)
            c.drawText(subtitle, tx, cy + px(23f), sub)
        }
    }
}

/** The panel under the user pill: Theme, Clock, Photos, Picture, Volume, Sleep and Settings. */
class QuickPanel(private val ctx: Context, private val host: HomeScreen) {
    companion object {
        fun use24(ctx: Context): Boolean {
            val p = ctx.getSharedPreferences("glass_quick", Context.MODE_PRIVATE)
            return if (p.contains("clock24")) p.getBoolean("clock24", true) else android.text.format.DateFormat.is24HourFormat(ctx)
        }
    }

    private val prefs = ctx.getSharedPreferences("glass_quick", Context.MODE_PRIVATE)
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val maxVol: Int get() = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    private val itemW = Backdrop.screenW * 228 / 1920
    private val itemH = Backdrop.screenH * 80 / 1080
    private val gap = Backdrop.screenW * 14 / 1920
    val theme = QuickItem(ctx, QuickItem.THEME, itemW, itemH)
    val clockBtn = QuickItem(ctx, QuickItem.CLOCK, itemW, itemH)
    val photos = QuickItem(ctx, QuickItem.PHOTOS, itemW, itemH)
    val picture = QuickItem(ctx, QuickItem.PICTURE, itemW, itemH)
    val slider = QuickItem(ctx, QuickItem.SLIDER, itemW * 2 + gap, itemH)
    val sleep = QuickItem(ctx, QuickItem.SLEEP, itemW, itemH)
    val settingsBtn = QuickItem(ctx, QuickItem.SETTINGS, itemW, itemH)
    val bottomId: Int get() = sleep.id
    var isLight = prefs.getBoolean("light", false)
        private set

    init {
        for (v in arrayOf(theme, clockBtn, photos, picture, slider, sleep, settingsBtn)) v.id = View.generateViewId()
        photos.subtitle = "Google Photos"
        picture.subtitle = "Consoles"
        sleep.subtitle = "Screen off"
        settingsBtn.subtitle = "GlassOS"
        slider.percent = readVolume()
        theme.onClick = { setLight(!isLight) }
        clockBtn.onClick = { setClock24(!use24(ctx)) }
        photos.onClick = { openPhotos() }
        picture.onClick = { openPicture() }
        slider.onChange = { applyVolume(it) }
        slider.onClick = { toggleMute() }
        sleep.onClick = { sleepNow() }
        settingsBtn.onClick = { host.openSettings() }
        restyle()
    }

    fun restyle() {
        for (v in arrayOf(theme, clockBtn, photos, picture, slider, sleep, settingsBtn)) v.light = isLight
        theme.subtitle = if (isLight) "White" else "Dark"
        clockBtn.subtitle = if (use24(ctx)) "24-hour" else "12-hour"
        slider.percent = readVolume()
    }

    fun attach(header: FrameLayout, edge: Int, ytop: Int) {
        val g = Gravity.TOP or Gravity.END
        val stepY = itemH + gap
        fun put(v: QuickItem, w: Int, col: Int, row: Int) {
            header.addView(v, FrameLayout.LayoutParams(w, itemH, g).apply {
                rightMargin = if (col == 0) edge + itemW + gap else edge
                topMargin = ytop + row * stepY
            })
        }
        put(theme, itemW, 0, 0)
        put(clockBtn, itemW, 1, 0)
        put(photos, itemW, 0, 1)
        put(picture, itemW, 1, 1)
        put(slider, itemW * 2 + gap, 1, 2)
        put(sleep, itemW, 0, 3)
        put(settingsBtn, itemW, 1, 3)
    }

    fun wire(gearId: Int, heroId: Int) {
        theme.nextFocusUpId = gearId
        theme.nextFocusLeftId = theme.id
        theme.nextFocusRightId = clockBtn.id
        theme.nextFocusDownId = photos.id
        clockBtn.nextFocusUpId = gearId
        clockBtn.nextFocusLeftId = theme.id
        clockBtn.nextFocusRightId = clockBtn.id
        clockBtn.nextFocusDownId = picture.id
        photos.nextFocusUpId = theme.id
        photos.nextFocusLeftId = photos.id
        photos.nextFocusRightId = picture.id
        photos.nextFocusDownId = slider.id
        picture.nextFocusUpId = clockBtn.id
        picture.nextFocusLeftId = photos.id
        picture.nextFocusRightId = picture.id
        picture.nextFocusDownId = slider.id
        slider.nextFocusUpId = photos.id
        slider.nextFocusDownId = sleep.id
        slider.nextFocusLeftId = slider.id
        slider.nextFocusRightId = slider.id
        sleep.nextFocusUpId = slider.id
        sleep.nextFocusLeftId = sleep.id
        sleep.nextFocusRightId = settingsBtn.id
        sleep.nextFocusDownId = heroId
        settingsBtn.nextFocusUpId = slider.id
        settingsBtn.nextFocusLeftId = sleep.id
        settingsBtn.nextFocusRightId = settingsBtn.id
        settingsBtn.nextFocusDownId = heroId
    }

    fun focusFirst() { theme.requestFocus() }

    fun invalidateAll() {
        slider.percent = readVolume()
        theme.invalidate()
        clockBtn.invalidate()
        photos.invalidate()
        picture.invalidate()
        slider.invalidate()
        sleep.invalidate()
        settingsBtn.invalidate()
    }

    private fun setLight(v: Boolean) {
        isLight = v
        prefs.edit().putBoolean("light", v).apply()
        restyle()
        host.applyTheme()
    }

    private fun setClock24(v: Boolean) {
        prefs.edit().putBoolean("clock24", v).apply()
        restyle()
        host.onClockChanged()
    }

    private fun openPhotos() {
        val pm = ctx.packageManager
        val fromList = HomeShare.apps?.firstOrNull { it.pkg.startsWith("com.google.android.apps.photos") }?.pkg
        val pkg = fromList ?: listOf("com.google.android.apps.photos", "com.google.android.apps.photos.tv").firstOrNull {
            pm.getLeanbackLaunchIntentForPackage(it) != null || pm.getLaunchIntentForPackage(it) != null
        }
        if (pkg == null) {
            Toast.makeText(ctx, "Google Photos is not installed on this TV", Toast.LENGTH_LONG).show()
            return
        }
        host.launch(pkg, photos)
    }

    private fun openPicture() {
        val hdmiInputs = HdmiManager.getInputs(ctx)
        val hdmiApps = hdmiInputs.map { entry ->
            val icon = HdmiManager.createIcon(ctx, entry.type, 128)
            AppEntry(
                pkg = "virtual.hdmi." + entry.id,
                label = entry.name,
                art = icon,
                isBanner = false,
                color = 0xFF222630.toInt()
            )
        }
        val cat = LibCat("Inputs", hdmiApps)
        host.openLibraryCategory(cat, picture)
    }

    private fun sleepNow() {
        try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(ctx.packageName, "io.github.abhishekkaisar.glassos.AdminReceiver")
            if (dpm.isAdminActive(admin)) {
                dpm.lockNow()
                return
            }
        } catch (e: Throwable) { }
        host.openControlCenter()
    }

    private fun readVolume(): Int = try {
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        (cur * 100 / maxVol).coerceIn(0, 100)
    } catch (e: Throwable) { 50 }

    private fun applyVolume(p: Int) {
        try {
            val target = Math.round(p * maxVol / 100f).coerceIn(0, maxVol)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
            slider.percent = (target * 100 / maxVol).coerceIn(0, 100)
        } catch (e: Throwable) { }
    }

    private fun toggleMute() {
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (cur > 0) {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
            slider.percent = 0
        } else {
            val half = (maxVol / 2).coerceAtLeast(1)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, half, AudioManager.FLAG_SHOW_UI)
            slider.percent = (half * 100 / maxVol).coerceIn(0, 100)
        }
    }
}