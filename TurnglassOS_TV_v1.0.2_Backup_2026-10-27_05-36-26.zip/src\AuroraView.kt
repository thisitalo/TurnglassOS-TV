package io.github.abhishekkaisar.glassos

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class AuroraView(ctx: Context) : View(ctx), Choreographer.FrameCallback {
    private val sw get() = Backdrop.screenW.toFloat()
    private val sh get() = Backdrop.screenH.toFloat()

    // 90 partículas libres que flotan y navegan por TODA la pantalla independientemente
    private class Mote(
        var x: Float,
        var y: Float,
        val vx: Float,
        val vy: Float,
        val radius: Float,
        val baseAlpha: Float,
        val pulseSpeed: Float,
        val phase: Float,
        val depth: Float,
        val isWarm: Boolean
    )

    private val motes = Array(90) { i ->
        val x = Math.random().toFloat()
        val y = Math.random().toFloat()
        val vx = -0.015f + Math.random().toFloat() * 0.030f
        val vy = -0.022f + Math.random().toFloat() * 0.012f
        val rad = 1.6f + Math.random().toFloat() * 3.4f
        val alpha = 0.30f + Math.random().toFloat() * 0.65f
        val pulse = 1.0f + Math.random().toFloat() * 2.2f
        val phase = (Math.random() * Math.PI * 2).toFloat()
        val depth = 0.2f + Math.random().toFloat() * 0.8f
        val isWarm = i % 3 == 0
        Mote(x, y, vx, vy, rad, alpha, pulse, phase, depth, isWarm)
    }

    private val bgPaint = Paint()
    private val spotPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Nostalgia PS: Cintas de seda horizontales
    private val ribbonTop = Path()
    private val ribbonMid = Path()
    private val ribbonBottom = Path()
    private val edgePaintTop = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.6f }
    private val edgePaintMid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3.2f }
    private val edgePaintBottom = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.0f }

    // Liquid Glass: Estructura escultórica de cristal fundido
    private val liquidMain = Path()
    private val liquidFold = Path()
    private val liquidLip = Path()
    private val liquidPaintMain = Paint(Paint.ANTI_ALIAS_FLAG)
    private val liquidPaintFold = Paint(Paint.ANTI_ALIAS_FLAG)
    private val liquidRimAmber = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3.8f }
    private val liquidRimCyan = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.8f }
    private val liquidSpecular = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f }

    // Luces de partículas
    private val moteGlow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val moteCore = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    var currentMode = "scene:nostalgia"
        private set
    private var colorIndex = 0
    private var liquidStyleIndex = 0
    private var running = false
    private var isAttached = false
    private var frameQueued = false
    private val startTime = SystemClock.uptimeMillis()

    init {
        setWillNotDraw(false)
        visibility = View.GONE
    }

    fun setMode(mode: String) {
        currentMode = mode
        updateShaders()
        invalidate()
    }

    fun setNostalgiaColor(index: Int) {
        colorIndex = index
        updateShaders()
        invalidate()
    }

    fun syncWeather(code: Int, isDay: Boolean) {
        when {
            code in 51..67 || code in 80..82 -> setNostalgiaColor(2)
            code in 71..77 || code in 85..86 -> setNostalgiaColor(4)
            code == 45 || code == 48 || code == 3 -> setNostalgiaColor(1)
            !isDay -> setNostalgiaColor(0)
            else -> setNostalgiaColor(3)
        }
        invalidate()
    }

    fun setLiquidStyle(index: Int) {
        liquidStyleIndex = index
        updateShaders()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        updateShaders()
    }

    private fun updateShaders() {
        val wf = if (width > 0) width.toFloat() else sw
        val hf = if (height > 0) height.toFloat() else sh

        if (currentMode == "scene:nostalgia") {
            val (spotCol, edgeCol) = when (colorIndex) {
                1 -> Pair(0x400A3818.toInt(), 0xCC34D399.toInt()) // Xbox Green
                2 -> Pair(0x452E104D.toInt(), 0xCCA78BFA.toInt()) // Amethyst Purple
                3 -> Pair(0x45400A12.toInt(), 0xCCF87171.toInt()) // Ruby Red
                4 -> Pair(0x351E222A.toInt(), 0xCCD1D5DB.toInt()) // Monochrome
                else -> Pair(0x450D274D.toInt(), 0xCC38BDF8.toInt()) // PlayStation Classic
            }

            bgPaint.color = 0xFF04060A.toInt()
            spotPaint.shader = RadialGradient(
                wf * 0.5f, hf * 0.15f, wf * 0.75f,
                intArrayOf(spotCol, 0x00000000),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )

            edgePaintTop.shader = LinearGradient(0f, 0f, wf, 0f,
                intArrayOf(0x00FFFFFF, 0x66FFFFFF, edgeCol, 0xEEFFFFFF.toInt(), 0x00FFFFFF),
                floatArrayOf(0f, 0.15f, 0.50f, 0.85f, 1f), Shader.TileMode.CLAMP)
            edgePaintMid.shader = LinearGradient(0f, 0f, wf, 0f,
                intArrayOf(0x00FFFFFF, edgeCol, 0xFFFFFFFF.toInt(), edgeCol, 0x00FFFFFF),
                floatArrayOf(0f, 0.20f, 0.55f, 0.80f, 1f), Shader.TileMode.CLAMP)
            edgePaintBottom.shader = LinearGradient(0f, 0f, wf, 0f,
                intArrayOf(0x00FFFFFF, 0x44FFFFFF, edgeCol, 0x99FFFFFF.toInt(), 0x00FFFFFF),
                floatArrayOf(0f, 0.30f, 0.65f, 0.90f, 1f), Shader.TileMode.CLAMP)

        } else {
            bgPaint.color = 0xFF020306.toInt()
            spotPaint.shader = RadialGradient(
                wf * 0.70f, hf * 0.35f, wf * 0.65f,
                intArrayOf(0x28182234, 0x00000000),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )

            liquidPaintMain.shader = LinearGradient(
                wf * 0.15f, hf * 0.85f, wf * 0.85f, hf * 0.15f,
                intArrayOf(0xDD070B12.toInt(), 0xEE161F2C.toInt(), 0xCC0A0F18.toInt(), 0xF005080E.toInt()),
                floatArrayOf(0f, 0.40f, 0.70f, 1f),
                Shader.TileMode.CLAMP
            )
            liquidPaintFold.shader = LinearGradient(
                wf * 0.3f, hf * 0.7f, wf * 0.7f, hf * 0.3f,
                intArrayOf(0xCC0C121D.toInt(), 0xE0222F42.toInt(), 0xBB080D15.toInt()),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )

            // Cáusticas ámbar y destellos cian
            liquidRimAmber.shader = LinearGradient(
                wf * 0.2f, hf * 0.6f, wf * 0.85f, hf * 0.2f,
                intArrayOf(0x00D97706, 0xCCF59E0B.toInt(), 0xFFFEF08A.toInt(), 0xAAF59E0B.toInt(), 0x00000000),
                floatArrayOf(0f, 0.30f, 0.60f, 0.85f, 1f),
                Shader.TileMode.CLAMP
            )
            liquidRimCyan.shader = LinearGradient(
                wf * 0.1f, hf * 0.9f, wf * 0.9f, hf * 0.3f,
                intArrayOf(0x0000E5FF, 0xB300E5FF.toInt(), 0xFFFFFFFF.toInt(), 0x8038BDF8.toInt(), 0x00000000),
                floatArrayOf(0f, 0.35f, 0.65f, 0.85f, 1f),
                Shader.TileMode.CLAMP
            )
            liquidSpecular.shader = LinearGradient(
                wf * 0.3f, hf * 0.6f, wf * 0.75f, hf * 0.25f,
                intArrayOf(0x00FFFFFF, 0xE6FFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0x33FFFFFF, 0x00FFFFFF),
                floatArrayOf(0f, 0.45f, 0.60f, 0.80f, 1f),
                Shader.TileMode.CLAMP
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isAttached = true
        if (running && visibility == View.VISIBLE) kick()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        isAttached = false
    }

    fun setRunning(on: Boolean) {
        running = on
        if (on && isAttached && visibility == View.VISIBLE) kick()
    }

    private fun kick() {
        if (frameQueued || !isAttached || visibility != View.VISIBLE) return
        frameQueued = true
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        frameQueued = false
        if (!isAttached || visibility != View.VISIBLE) return

        val t = (SystemClock.uptimeMillis() - startTime) * 0.001f
        val wf = if (width > 0) width.toFloat() else sw
        val hf = if (height > 0) height.toFloat() else sh

        // Mover las 90 partículas libres por toda la pantalla
        for (m in motes) {
            m.x += m.vx * 0.016f
            m.y += m.vy * 0.016f + sin((t * 0.5f + m.phase).toDouble()).toFloat() * 0.0005f

            if (m.x < -0.05f) m.x = 1.05f
            if (m.x > 1.05f) m.x = -0.05f
            if (m.y < -0.05f) m.y = 1.05f
            if (m.y > 1.05f) m.y = -0.05f
        }

        if (currentMode == "scene:nostalgia") {
            buildPsRibbon(t, wf, hf)
        } else {
            buildLiquidRibbon(t, wf, hf)
        }

        invalidate()
        if (running) kick()
    }

    private fun buildPsRibbon(t: Float, wf: Float, hf: Float) {
        ribbonTop.reset()
        ribbonMid.reset()
        ribbonBottom.reset()

        val steps = 36
        val baseY = hf * 0.50f

        val yT0 = baseY - 24f + sin((t * 0.70f).toDouble()).toFloat() * 35f
        ribbonTop.moveTo(0f, yT0)
        for (i in 1..steps) {
            val xn = i / steps.toFloat()
            val y = baseY - 24f + sin((xn * 3.4f + t * 0.65f).toDouble()).toFloat() * 48f +
                    cos((xn * 1.8f - t * 0.40f).toDouble()).toFloat() * 22f
            ribbonTop.lineTo(xn * wf, y)
        }

        val yM0 = baseY + 12f + sin((t * 0.55f + 1.2f).toDouble()).toFloat() * 42f
        ribbonMid.moveTo(0f, yM0)
        for (i in 1..steps) {
            val xn = i / steps.toFloat()
            val y = baseY + 8f + sin((xn * 2.8f - t * 0.50f + 1.4f).toDouble()).toFloat() * 56f +
                    cos((xn * 2.2f + t * 0.35f).toDouble()).toFloat() * 28f
            ribbonMid.lineTo(xn * wf, y)
        }

        val yB0 = baseY + 36f + cos((t * 0.60f + 2.1f).toDouble()).toFloat() * 30f
        ribbonBottom.moveTo(0f, yB0)
        for (i in 1..steps) {
            val xn = i / steps.toFloat()
            val y = baseY + 32f + cos((xn * 3.0f + t * 0.45f + 2.0f).toDouble()).toFloat() * 44f +
                    sin((xn * 1.5f - t * 0.30f).toDouble()).toFloat() * 20f
            ribbonBottom.lineTo(xn * wf, y)
        }
    }

    private fun buildLiquidRibbon(t: Float, wf: Float, hf: Float) {
        liquidMain.reset()
        liquidFold.reset()
        liquidLip.reset()

        val p = sin((t * 0.35f).toDouble()).toFloat()
        val q = cos((t * 0.28f).toDouble()).toFloat()

        liquidMain.moveTo(-wf * 0.1f, hf * 0.95f)
        liquidMain.cubicTo(
            wf * 0.22f + p * 25f, hf * 0.78f + q * 30f,
            wf * 0.45f - q * 30f, hf * 0.58f + p * 35f,
            wf * 0.68f + p * 20f, hf * 0.32f - q * 25f
        )
        liquidMain.cubicTo(
            wf * 0.82f + q * 25f, hf * 0.18f - p * 20f,
            wf * 0.92f - p * 15f, hf * 0.08f + q * 15f,
            wf * 1.05f, -hf * 0.05f
        )
        liquidMain.lineTo(wf * 1.15f, hf * 0.15f)
        liquidMain.cubicTo(
            wf * 0.85f, hf * 0.35f,
            wf * 0.65f + q * 20f, hf * 0.65f - p * 25f,
            wf * 0.35f - p * 25f, hf * 0.88f + q * 20f
        )
        liquidMain.lineTo(-wf * 0.1f, hf * 1.1f)
        liquidMain.close()

        liquidLip.moveTo(-wf * 0.08f, hf * 0.93f)
        liquidLip.cubicTo(
            wf * 0.23f + p * 25f, hf * 0.76f + q * 28f,
            wf * 0.46f - q * 28f, hf * 0.56f + p * 32f,
            wf * 0.69f + p * 20f, hf * 0.30f - q * 24f
        )
        liquidLip.cubicTo(
            wf * 0.83f + q * 22f, hf * 0.16f - p * 18f,
            wf * 0.93f - p * 14f, hf * 0.06f + q * 14f,
            wf * 1.05f, -hf * 0.07f
        )

        liquidFold.moveTo(wf * 0.15f, hf * 0.85f)
        liquidFold.cubicTo(
            wf * 0.35f - q * 20f, hf * 0.68f + p * 22f,
            wf * 0.52f + p * 24f, hf * 0.46f - q * 20f,
            wf * 0.78f + q * 18f, hf * 0.22f + p * 16f
        )
    }

    override fun onDraw(c: Canvas) {
        val wf = width.toFloat()
        val hf = height.toFloat()
        val t = (SystemClock.uptimeMillis() - startTime) * 0.001f

        c.drawRect(0f, 0f, wf, hf, bgPaint)
        c.drawRect(0f, 0f, wf, hf, spotPaint)

        // Partículas en el fondo
        drawMotes(c, wf, hf, t, isFore = false)

        if (currentMode == "scene:nostalgia") {
            c.drawPath(ribbonTop, edgePaintTop)
            c.drawPath(ribbonBottom, edgePaintBottom)
            c.drawPath(ribbonMid, edgePaintMid)
        } else {
            c.drawPath(liquidMain, liquidPaintMain)
            c.drawPath(liquidFold, liquidPaintFold)
            c.drawPath(liquidLip, liquidRimAmber)
            c.drawPath(liquidMain, liquidRimCyan)
            c.drawPath(liquidFold, liquidSpecular)
        }

        // Partículas al frente
        drawMotes(c, wf, hf, t, isFore = true)
    }

    private fun drawMotes(c: Canvas, wf: Float, hf: Float, t: Float, isFore: Boolean) {
        for (m in motes) {
            val belongsFore = m.depth > 0.55f
            if (belongsFore != isFore) continue

            val cx = m.x * wf
            val cy = m.y * hf
            val pulse = (sin((t * m.pulseSpeed + m.phase).toDouble()).toFloat() * 0.35f + 0.65f)
            val currentAlpha = (m.baseAlpha * pulse).coerceIn(0f, 1f)
            val r = m.radius * (0.8f + pulse * 0.3f)

            if (currentMode == "scene:nostalgia") {
                val glowCol = when (colorIndex) {
                    1 -> 0x6634D399.toInt()
                    2 -> 0x66A78BFA.toInt()
                    3 -> 0x66F87171.toInt()
                    4 -> 0x55E2E8F0.toInt()
                    else -> 0x6638BDF8.toInt()
                }
                moteGlow.color = glowCol
            } else {
                moteGlow.color = if (m.isWarm) 0x66F59E0B.toInt() else 0x6638BDF8.toInt()
            }

            moteGlow.alpha = (currentAlpha * 140).toInt()
            c.drawCircle(cx, cy, r * 2.5f, moteGlow)

            moteCore.alpha = (currentAlpha * 240).toInt()
            c.drawCircle(cx, cy, r * 0.75f, moteCore)
        }
    }
}