package io.github.abhishekkaisar.glassos

import android.content.Context
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/**
 * Reloj minimalista de la esquina superior izquierda para el Modo Ambiente.
 * Muestra: [Hora] [Icono del clima animado] [Temperatura°] (sin el nombre de la ciudad).
 */
class AmbientClockView(private val ctx: Context) : LinearLayout(ctx) {
    private val clock = TextClock(ctx)
    private val icon = WeatherIcon(ctx, Backdrop.screenH * 32 / 1080)
    private val tempView = TextView(ctx)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        visibility = View.GONE
        alpha = 0f
        clipChildren = false
        clipToPadding = false

        val sh = Backdrop.screenH

        // 1. Reloj minimalista con sombra suave
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, sh * 36 / 1080f)
        clock.typeface = Typeface.create(Fonts.regular, Typeface.BOLD)
        clock.setTextColor(0xF7FFFFFF.toInt())
        clock.setShadowLayer(ctx.dp(8f), 0f, ctx.dp(1.5f), 0x99000000.toInt())
        clock.includeFontPadding = false
        applyFormat()

        // 2. Icono vectorial del clima
        val iconGap = ctx.dpi(12f)
        val iconLp = LayoutParams(-2, -2).apply {
            leftMargin = iconGap
            rightMargin = ctx.dpi(6f)
        }

        // 3. Temperatura pura (°C / °)
        tempView.setTextSize(TypedValue.COMPLEX_UNIT_PX, sh * 30 / 1080f)
        tempView.typeface = Fonts.medium
        tempView.setTextColor(0xE6FFFFFF.toInt())
        tempView.setShadowLayer(ctx.dp(8f), 0f, ctx.dp(1.5f), 0x99000000.toInt())
        tempView.includeFontPadding = false

        addView(clock, LayoutParams(-2, -2))
        addView(icon, iconLp)
        addView(tempView, LayoutParams(-2, -2))
    }

    fun applyFormat() {
        val f = if (QuickPanel.use24(ctx)) "HH:mm" else "h:mm"
        clock.format12Hour = f
        clock.format24Hour = f
    }

    fun updateWeather() {
        val wx = WelcomeCard.cached
        if (wx != null && wx.temp != null) {
            icon.code = wx.code
            icon.day = wx.day
            tempView.text = "${wx.temp}\u00B0"
            icon.visibility = View.VISIBLE
            tempView.visibility = View.VISIBLE
        } else {
            icon.visibility = View.GONE
            tempView.visibility = View.GONE
        }
    }

    fun show() {
        applyFormat()
        updateWeather()
        visibility = View.VISIBLE
        animate().cancel()
        animate().alpha(1f).setDuration(800L).setInterpolator(DecelerateInterpolator()).start()
    }

    fun hide() {
        if (visibility != View.VISIBLE) return
        animate().cancel()
        animate().alpha(0f).setDuration(250L).withEndAction {
            visibility = View.GONE
        }.start()
    }
}